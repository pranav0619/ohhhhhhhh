"""
CollabSpace v1.0 — Main Entry Point
=====================================
Run:   python main.py
Requires: Python 3.10+ (tkinter included in standard library)
"""
import tkinter as tk
from tkinter import messagebox
import sys
import os

# Ensure the project root is on sys.path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from data.storage           import Storage
from core.project_manager   import ProjectManager
from core.task_manager      import TaskManager
from core.note_manager      import NoteManager
from core.file_manager      import FileManager
from core.executor          import CodeExecutor
from core.user_manager      import UserManager
from ui.dashboard           import Dashboard


class CollabSpaceApp:
    """Root application — wires all layers, owns the Tk window."""

    def __init__(self):
        self.root = tk.Tk()
        self.root.title("CollabSpace  v1.0")
        self.root.geometry("1400x860")
        self.root.minsize(1100, 700)
        self.root.configure(bg="#0f0f11")
        self._center_window()

        # ── Data layer ────────────────────────────────────────────────────
        # Optional remote URL for shared database server (set in %COLLABSPACE_REMOTE% environment variable)
        remote_url = os.environ.get('COLLABSPACE_REMOTE')
        self.storage = Storage(remote_url=remote_url)

        # ── Core layer ────────────────────────────────────────────────────
        self.project_manager = ProjectManager(self.storage)
        self.task_manager    = TaskManager(self.storage)
        self.note_manager    = NoteManager(self.storage)
        self.user_manager    = UserManager(self.storage)
        self.file_manager    = FileManager()
        self.executor        = CodeExecutor()

        # ── UI layer ──────────────────────────────────────────────────────
        self.dashboard = Dashboard(
            parent          = self.root,
            project_manager = self.project_manager,
            task_manager    = self.task_manager,
            note_manager    = self.note_manager,
            file_manager    = self.file_manager,
            executor        = self.executor,
            user_manager    = self.user_manager,
        )
        self.dashboard.pack(fill=tk.BOTH, expand=True)

        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

    def _center_window(self):
        self.root.update_idletasks()
        w  = 1400; h = 860
        sw = self.root.winfo_screenwidth()
        sh = self.root.winfo_screenheight()
        self.root.geometry(f"{w}x{h}+{(sw-w)//2}+{(sh-h)//2}")

    def _on_close(self):
        if messagebox.askokcancel("Quit", "Exit CollabSpace?"):
            if hasattr(self.dashboard, "shutdown_services"):
                self.dashboard.shutdown_services()
            self.storage.flush()
            self.executor.terminate()
            self.root.destroy()

    def run(self):
        self.root.mainloop()


if __name__ == "__main__":
    app = CollabSpaceApp()
    app.run()
