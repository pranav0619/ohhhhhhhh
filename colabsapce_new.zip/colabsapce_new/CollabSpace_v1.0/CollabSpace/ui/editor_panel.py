"""ui/editor_panel.py — multi-tab code editor."""
import tkinter as tk
import re, threading, subprocess, sys, os
from ui.theme import *
from ui import syntax as syn
from core.executor import CodeExecutor
from ui.dialogs import ask_text

class _Tab:
    def __init__(self, name, content="", proj_id=""):
        self.name=name; self.content=content; self.proj_id=proj_id; self.dirty=False

    @property
    def label(self):
        return ("● "+self.name) if self.dirty else self.name

class EditorPanel(tk.Frame):
    def __init__(self, parent, executor: CodeExecutor, on_save):
        super().__init__(parent, bg=BG)
        self._ex = executor
        self._on_save      = on_save
        self._proc = None; self._thread = None; self._shell_running = False
        self._project      = None
        self._tabs: list[_Tab] = []
        self._active = 0
        self._font_size = 11
        self._find_open = False
        self._find_matches = []
        self._find_cursor  = -1
        self._build()
        self._open_scratch()

    # ── Build ──────────────────────────────────────────────────────────────────
    def _build(self):
        # Tab bar
        self._tab_bar = tk.Frame(self, bg=PANEL2, height=34)
        self._tab_bar.pack_propagate(False)
        self._tab_bar.pack(fill=tk.X)
        separator(self, bg=BORDER)

        # Toolbar
        tb = tk.Frame(self, bg=PANEL, pady=5)
        tb.pack(fill=tk.X)
        self._proj_lbl = tk.Label(tb, text="  No project", bg=PANEL,
                                   fg=DIM, font=("Segoe UI",9,"italic"))
        self._proj_lbl.pack(side=tk.LEFT)

        self._run_btn = btn(tb, "▶  Run", self._run,
                            bg=ACCENT, fg="white", abg=ACCENT2)
        self._run_btn.pack(side=tk.RIGHT, padx=2)

        btn(tb, "💾 Save", self._save, font=FONT_SM).pack(side=tk.RIGHT, padx=2)
        btn(tb, "🔍 Find", self._toggle_find, font=FONT_SM).pack(side=tk.RIGHT, padx=2)

        # Zoom
        zf = tk.Frame(tb, bg=PANEL); zf.pack(side=tk.RIGHT, padx=6)
        btn(zf,"A-", self._zoom_out, bg=PANEL, fg=DIM, abg=PANEL2, px=4, py=2).pack(side=tk.LEFT)
        btn(zf,"A+", self._zoom_in,  bg=PANEL, fg=DIM, abg=PANEL2, px=4, py=2).pack(side=tk.LEFT)

        self._lang_lbl = tk.Label(tb, text="Python", bg=PANEL, fg=DIM, font=FONT_XS)
        self._lang_lbl.pack(side=tk.RIGHT, padx=8)

        # Find bar (hidden initially)
        self._find_bar = tk.Frame(self, bg=PANEL2, pady=4)
        self._find_var = tk.StringVar()
        tk.Label(self._find_bar, text=" Find:", bg=PANEL2, fg=DIM, font=FONT_SM).pack(side=tk.LEFT)
        self._find_entry = tk.Entry(self._find_bar, textvariable=self._find_var,
                                    bg=BORDER, fg=TEXT, insertbackground=TEXT,
                                    relief=tk.FLAT, bd=4, font=FONT_SM, width=22)
        self._find_entry.pack(side=tk.LEFT, padx=4)
        self._find_var.trace_add("write", lambda *_: self._do_find())
        btn(self._find_bar,"▲",self._find_prev,bg=PANEL2,fg=TEXT,px=6,py=2).pack(side=tk.LEFT)
        btn(self._find_bar,"▼",self._find_next,bg=PANEL2,fg=TEXT,px=6,py=2).pack(side=tk.LEFT)
        self._find_count = tk.Label(self._find_bar, text="", bg=PANEL2, fg=DIM, font=FONT_XS)
        self._find_count.pack(side=tk.LEFT, padx=6)
        btn(self._find_bar,"✕",self._close_find,bg=PANEL2,fg=DIM,abg=ERROR,px=6,py=2).pack(side=tk.RIGHT,padx=4)
        self._find_entry.bind("<Return>",       lambda _: self._find_next())
        self._find_entry.bind("<Shift-Return>",  lambda _: self._find_prev())
        self._find_entry.bind("<Escape>",        lambda _: self._close_find())

        # Editor + output: vertical split (drag sash to resize console)
        self._editor_split = tk.PanedWindow(
            self,
            orient=tk.VERTICAL,
            sashwidth=6,
            sashrelief=tk.FLAT,
            bg=BORDER,
            bd=0,
        )
        self._editor_split.pack(fill=tk.BOTH, expand=True)
        self._last_console_sash = 420
        self._editor_split.bind("<ButtonRelease-1>", self._on_split_sash_moved)

        top_block = tk.Frame(self._editor_split, bg=BG)

        # Editor area
        ed_frame = tk.Frame(top_block, bg=BG)
        ed_frame.pack(fill=tk.BOTH, expand=True)

        # Line numbers
        self._gutter = tk.Text(ed_frame, width=4, bg="#0d0d10", fg="#495162",
                                font=self._mfont(), bd=0, relief=tk.FLAT,
                                state=tk.DISABLED, cursor="arrow", padx=6, pady=6)
        self._gutter.pack(side=tk.LEFT, fill=tk.Y)
        tk.Frame(ed_frame, bg=BORDER, width=1).pack(side=tk.LEFT, fill=tk.Y)

        ef2 = tk.Frame(ed_frame, bg=BG)
        ef2.pack(fill=tk.BOTH, expand=True)
        vsb = tk.Scrollbar(ef2, bg=PANEL2, troughcolor=BG, width=8, bd=0)
        vsb.pack(side=tk.RIGHT, fill=tk.Y)
        hsb = tk.Scrollbar(ef2, orient=tk.HORIZONTAL, bg=PANEL2, troughcolor=BG, width=8, bd=0)
        hsb.pack(side=tk.BOTTOM, fill=tk.X)

        self._text = tk.Text(ef2, bg=BG, fg=TEXT, insertbackground=TEXT,
                              font=self._mfont(), bd=0, relief=tk.FLAT,
                              wrap=tk.NONE, undo=True, padx=12, pady=6,
                              selectbackground="#264f78", selectforeground=TEXT,
                              yscrollcommand=self._sync_scroll,
                              xscrollcommand=hsb.set)
        self._text.pack(fill=tk.BOTH, expand=True)
        vsb.config(command=self._vscroll)
        hsb.config(command=self._text.xview)
        bind_mousewheel(self._text, self._text.yview)

        syn.setup_tags(self._text)
        self._text.tag_config("find_match", background="#613214", foreground=TEXT)

        self._text.bind("<KeyRelease>",      self._on_key)
        self._text.bind("<ButtonRelease-1>", lambda _: self._update_status())
        self._text.bind("<Tab>",             self._on_tab)
        self._text.bind("<Control-s>",       lambda _: self._save())
        self._text.bind("<Control-f>",       lambda _: self._toggle_find())
        self._text.bind("<Control-equal>",   lambda _: self._zoom_in())
        self._text.bind("<Control-minus>",   lambda _: self._zoom_out())

        # Auto-close brackets and quotes
        self._text.bind('(', lambda e: self._auto_close('(', ')'))
        self._text.bind('[', lambda e: self._auto_close('[', ']'))
        self._text.bind('{', lambda e: self._auto_close('{', '}'))
        self._text.bind('"', lambda e: self._auto_close('"', '"'))
        self._text.bind("'", lambda e: self._auto_close("'", "'"))

        # Status bar (above output split)
        sb = tk.Frame(top_block, bg=ACCENT, pady=2)
        sb.pack(fill=tk.X, side=tk.BOTTOM)
        self._status = tk.Label(sb, text=" Ln 1, Col 1", bg=ACCENT, fg="white", font=FONT_XS)
        self._status.pack(side=tk.LEFT)
        self._dirty_lbl = tk.Label(sb, text="", bg=ACCENT, fg=WARN, font=FONT_XS)
        self._dirty_lbl.pack(side=tk.RIGHT, padx=8)
        self._file_lbl = tk.Label(sb, text="", bg=ACCENT, fg="white", font=FONT_XS)
        self._file_lbl.pack(side=tk.RIGHT, padx=8)

        # Console
        self._console_frame = tk.Frame(self._editor_split, bg="#09090d")
        self._console_visible = True

        chdr = tk.Frame(self._console_frame, bg=PANEL, pady=3)
        chdr.pack(fill=tk.X)
        tk.Label(chdr, text="  OUTPUT CONSOLE", bg=PANEL, fg=DIM,
                 font=("Segoe UI",8,"bold")).pack(side=tk.LEFT)
        tk.Label(
            chdr,
            text="  (drag bar above to resize)",
            bg=PANEL,
            fg=DIM,
            font=FONT_XS,
        ).pack(side=tk.LEFT)
        btn(chdr,"Clear",self._clear_console,bg=PANEL,fg=DIM,abg=PANEL2,
            font=FONT_XS,px=6,py=2).pack(side=tk.RIGHT,padx=6)
        self._console_toggle_btn = btn(
            chdr, "▼ Hide", self._toggle_console, bg=PANEL, fg=DIM, abg=PANEL2,
            font=FONT_XS, px=6, py=2,
        )
        self._console_toggle_btn.pack(side=tk.RIGHT)


        # Input field for sending input to running program
        self._input_frame = tk.Frame(self._console_frame, bg=PANEL, pady=2)
        self._input_var = tk.StringVar()
        tk.Label(self._input_frame, text=" Input:", bg=PANEL, fg=DIM, font=FONT_SM).pack(side=tk.LEFT)
        self._input_entry = tk.Entry(self._input_frame, textvariable=self._input_var,
                                     bg=BORDER, fg=TEXT, insertbackground=TEXT,
                                     relief=tk.FLAT, bd=4, font=FONT_SM)
        self._input_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=4)
        self._input_entry.bind("<Return>", self._send_input)
        self._input_frame.pack(fill=tk.X)
        self._input_frame.pack_forget()  # hidden initially

        cf = tk.Frame(self._console_frame, bg="#09090d")
        cf.pack(fill=tk.BOTH, expand=True)
        cvsb = tk.Scrollbar(cf, bg=PANEL2, troughcolor="#09090d", width=8, bd=0)
        cvsb.pack(side=tk.RIGHT, fill=tk.Y)
        self._console = tk.Text(cf, bg="#09090d", fg="#cccccc", font=FONT_MONO_SM,
                                 bd=0, relief=tk.FLAT, state=tk.DISABLED,
                                 wrap=tk.WORD, height=6, padx=10, pady=6,
                                 yscrollcommand=cvsb.set)
        self._console.pack(fill=tk.BOTH, expand=True)
        cvsb.config(command=self._console.yview)
        self._console.tag_config("info",    foreground=BLUE)
        self._console.tag_config("success", foreground=SUCCESS)
        self._console.tag_config("error",   foreground=ERROR)
        self._console.tag_config("warn",    foreground=WARN)
        self.console_append("  Terminal ready. Type commands or click ▶ Run.\n","info")
        self._start_shell()

        self._editor_split.add(top_block, minsize=120)
        self._editor_split.add(self._console_frame, minsize=64)
        self.after_idle(self._apply_initial_console_sash)

    def _apply_initial_console_sash(self):
        try:
            h = max(self._editor_split.winfo_height(), 200)
            self._editor_split.sash_place(0, 1, max(150, h - 200))
        except tk.TclError:
            self._editor_split.sash_place(0, 1, self._last_console_sash)

    def _on_split_sash_moved(self, _event=None):
        try:
            _, self._last_console_sash = self._editor_split.sash_coord(0)
        except tk.TclError:
            pass

    def _auto_close(self, open_char, close_char):
        self._text.insert(tk.INSERT, open_char + close_char)
        self._text.mark_set(tk.INSERT, f"{tk.INSERT} -1c")
        return "break"

    def _start_shell(self):
        try:
            cwd = self._project.path if self._project and self._project.path else os.path.expanduser("~")
            self._proc = subprocess.Popen(
                ['powershell'],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                cwd=cwd
            )
            self._shell_running = True
            self._thread = threading.Thread(target=self._read_shell_output, daemon=True)
            self._thread.start()
            self.console_append(f"Terminal started in {cwd or 'default directory'}\n", "info")
        except Exception as e:
            self.console_append(f"Failed to start shell: {e}\n", "error")

    def _read_shell_output(self):
        while self._shell_running and self._proc:
            try:
                line = self._proc.stdout.readline()
                if line:
                    self.after(0, self.console_append, line)
                elif self._proc.poll() is not None:
                    break
            except:
                break
        self._shell_running = False

    def _restart_shell(self):
        if self._proc:
            try: self._proc.terminate()
            except: pass
        self._start_shell()
        if self._project and self._project.path:
            self.after(1000, lambda: self._send_cd(self._project.path))

    def _send_cd(self, path):
        if self._proc and self._shell_running:
            try:
                self._proc.stdin.write(f'cd "{path}"\n')
                self._proc.stdin.flush()
            except Exception as e:
                self.console_append(f"Error cd: {e}\n", "error")

    # ── Tabs ───────────────────────────────────────────────────────────────────
    def _open_scratch(self):
        s = _Tab("Scratch","# Welcome to CollabSpace v1.0\n# ▶ Run | 💾 Save (Ctrl+S) | 🔍 Find (Ctrl+F)\n\nprint('Hello, CollabSpace!')\n")
        self._tabs = [s]; self._active = 0
        self._rebuild_tabs(); self._load_tab(0)

    def open_file(self, name, content, proj_id=""):
        for i,t in enumerate(self._tabs):
            if t.name==name and t.proj_id==proj_id:
                self._switch(i); return
        t = _Tab(name, content, proj_id)
        self._tabs.append(t)
        self._rebuild_tabs(); self._switch(len(self._tabs)-1)

    def _rebuild_tabs(self):
        for w in self._tab_bar.winfo_children(): w.destroy()
        for i,t in enumerate(self._tabs):
            active = (i==self._active)
            bg = BG if active else TAB_BG if hasattr(self,"TAB_BG") else PANEL2
            fg = TEXT if active else DIM
            f  = tk.Frame(self._tab_bar, bg=bg, cursor="hand2")
            f.pack(side=tk.LEFT)
            if active:
                tk.Frame(f, bg=ACCENT, height=2).pack(fill=tk.X)
            else:
                tk.Frame(f, bg=PANEL2, height=2).pack(fill=tk.X)
            inner = tk.Frame(f, bg=bg)
            inner.pack(fill=tk.X, padx=1)
            lbl = tk.Label(inner, text=f"  {t.label}  ", bg=bg, fg=fg,
                           font=("Segoe UI",9,"bold") if active else FONT_SM,
                           cursor="hand2")
            lbl.pack(side=tk.LEFT, pady=4)
            lbl.bind("<Button-1>", lambda e, idx=i: self._switch(idx))
            if len(self._tabs)>1 or t.name!="Scratch":
                x = tk.Label(inner, text="×", bg=bg, fg=DIM,
                             font=("Segoe UI",10), cursor="hand2")
                x.pack(side=tk.LEFT, padx=(0,4), pady=4)
                x.bind("<Button-1>", lambda e, idx=i: self._close_tab(idx))
            tk.Frame(self._tab_bar, bg=BORDER, width=1).pack(side=tk.LEFT, fill=tk.Y)
        tk.Frame(self._tab_bar, bg=BORDER, height=1).pack(side=tk.BOTTOM, fill=tk.X)

    def _switch(self, idx):
        if self._tabs and self._tabs[self._active].dirty:
            self._save()
        self._snapshot(); self._active=idx; self._load_tab(idx)

    def _load_tab(self, idx):
        if idx<0 or idx>=len(self._tabs): return
        t = self._tabs[idx]
        self._text.config(state=tk.NORMAL)
        self._text.delete("1.0", tk.END)
        self._text.insert("1.0", t.content)
        self._text.edit_reset()
        ext = t.name.split('.')[-1].lower() if '.' in t.name else 'py'
        syn.highlight(self._text, ext)
        self._update_gutter(); self._update_status(); self._update_dirty()
        self._rebuild_tabs()
        self._file_lbl.config(text=t.name)

    def _snapshot(self):
        if not self._tabs: return
        t = self._tabs[self._active]
        cur = self._text.get("1.0","end-1c")
        if cur != t.content: t.dirty=True
        t.content = cur

    def _close_tab(self, idx):
        t = self._tabs[idx]
        if t.dirty:
            from tkinter import messagebox
            if not messagebox.askyesno("Unsaved","Close without saving?"): return
        self._tabs.pop(idx)
        if not self._tabs: self._open_scratch(); return
        self._active = max(0, min(idx, len(self._tabs)-1))
        self._load_tab(self._active)

    # ── Public API ─────────────────────────────────────────────────────────────
    def set_project(self, project):
        self._project = project
        self._restart_shell()
        self.console_append(f"Project set to: {project.path}\n", "info")
        if project:
            self._proj_lbl.config(text=f"  {project.name}", fg=TEXT,
                                   font=("Segoe UI",9,"bold"))
        else:
            self._proj_lbl.config(text="  No project", fg=DIM,
                                   font=("Segoe UI",9,"italic"))

    def get_source(self):
        return self._text.get("1.0", tk.END)

    def current_tab(self) -> _Tab | None:
        if self._tabs: return self._tabs[self._active]
        return None

    # ── Save ───────────────────────────────────────────────────────────────────
    def _save(self):
        self._snapshot()
        t = self.current_tab()
        if not t: return
        if t.name == "Scratch":
            name = ask_text(self, "Save File", "File name (e.g. main.py):")
            if not name: return
            t.name = name.strip()
        t.dirty = False
        self._rebuild_tabs(); self._update_dirty()
        if self._on_save:
            try:
                self._on_save(t.name, t.content)
            except Exception as e:
                self.console_append(f"Save failed: {e}\n", "error")
        self.console_append(f"  ✔ Saved: {t.name}\n", "success")

    # ── Run / Stop ─────────────────────────────────────────────────────────────
    def _run(self):
        src = self.get_source()
        if not src.strip(): return
        tab = self._tabs[self._active]
        ext = tab.name.split('.')[-1].lower() if '.' in tab.name else 'py'
        if ext not in ['py', 'js', 'html']:
            ext = 'py'
        self._lang_lbl.config(text=ext.upper())
        # Save the file first
        self._save()
        # Get the file path
        import os
        file_path = tab.name
        # Send command to terminal
        cmd_dict = {"py": "python", "js": "node", "html": "start"}
        cmd = cmd_dict.get(ext, "python") + f' "{file_path}"'
        self.console_append(f"Running: {cmd}\n", "info")
        if self._proc and self._shell_running:
            try:
                self._proc.stdin.write(cmd + "\n")
                self._proc.stdin.flush()
            except Exception as e:
                self.console_append(f"Error running: {e}\n", "error")
        else:
            self.console_append("Terminal not running\n", "error")

    def _send_input(self, event=None):
        text = self._input_var.get()
        if not text: return "break"
        self._input_var.set("")
        if self._proc and self._shell_running:
            try:
                self._proc.stdin.write(text + '\n')
                self._proc.stdin.flush()
            except Exception as e:
                self.console_append(f"Error: {e}\n", "error")
        else:
            self.console_append("Shell not running\n", "error")
        return "break"

    # ── Console ────────────────────────────────────────────────────────────────
    def console_append(self, text, tag=""):
        self._console.config(state=tk.NORMAL)
        self._console.insert(tk.END, text, tag)
        self._console.see(tk.END)
        self._console.config(state=tk.DISABLED)

    def _clear_console(self):
        self._console.config(state=tk.NORMAL)
        self._console.delete("1.0", tk.END)
        self._console.config(state=tk.DISABLED)

    def _toggle_console(self):
        if self._console_visible:
            try:
                _, self._last_console_sash = self._editor_split.sash_coord(0)
            except tk.TclError:
                pass
            self._editor_split.forget(self._console_frame)
            self._console_toggle_btn.config(text="▲ Show")
        else:
            self._editor_split.add(self._console_frame, minsize=64)
            self._console_toggle_btn.config(text="▼ Hide")
            self.after_idle(lambda: self._editor_split.sash_place(0, 1, self._last_console_sash))
        self._console_visible = not self._console_visible

    # ── Find ───────────────────────────────────────────────────────────────────
    def _toggle_find(self):
        if self._find_open: self._close_find()
        else:
            self._find_bar.pack(fill=tk.X, after=self._tab_bar)
            self._find_open = True; self._find_entry.focus_set()

    def _close_find(self):
        self._find_bar.pack_forget(); self._find_open = False
        self._text.tag_remove("find_match","1.0",tk.END)
        self._find_matches=[]; self._find_cursor=-1
        self._find_count.config(text="")

    def _do_find(self):
        self._text.tag_remove("find_match","1.0",tk.END)
        self._find_matches=[]; self._find_cursor=-1
        q = self._find_var.get()
        if not q: self._find_count.config(text=""); return
        code = self._text.get("1.0",tk.END)
        for m in re.finditer(re.escape(q), code, re.IGNORECASE):
            s=f"1.0+{m.start()}c"; e=f"1.0+{m.end()}c"
            self._text.tag_add("find_match", s, e)
            self._find_matches.append(s)
        n=len(self._find_matches)
        self._find_count.config(text=f"{n} match{'es' if n!=1 else ''}")
        if self._find_matches: self._find_cursor=0; self._scroll_match(0)

    def _find_next(self):
        if not self._find_matches: return
        self._find_cursor=(self._find_cursor+1)%len(self._find_matches)
        self._scroll_match(self._find_cursor)

    def _find_prev(self):
        if not self._find_matches: return
        self._find_cursor=(self._find_cursor-1)%len(self._find_matches)
        self._scroll_match(self._find_cursor)

    def _scroll_match(self, idx):
        pos=self._find_matches[idx]; self._text.see(pos); self._text.mark_set(tk.INSERT,pos)

    # ── Zoom ───────────────────────────────────────────────────────────────────
    def _zoom_in(self):
        if self._font_size<28: self._font_size+=1; self._apply_font()
    def _zoom_out(self):
        if self._font_size>8:  self._font_size-=1; self._apply_font()
    def _apply_font(self):
        f=self._mfont(); self._text.config(font=f); self._gutter.config(font=f)
    def _mfont(self): return ("Consolas", self._font_size)

    # ── Editor events ──────────────────────────────────────────────────────────
    def _on_key(self, _=None):
        self._update_gutter()
        ext = self.current_tab().name.split('.')[-1].lower() if '.' in self.current_tab().name else 'py'
        syn.highlight(self._text, ext)
        self._update_status()
        if self._tabs:
            t=self._tabs[self._active]; cur=self._text.get("1.0","end-1c")
            if cur!=t.content: t.dirty=True; self._update_dirty()

    def _on_tab(self, _):
        self._text.insert(tk.INSERT,"    "); return "break"

    def _sync_scroll(self, *a):
        self._gutter.yview_moveto(a[0])

    def _vscroll(self, *a):
        self._text.yview(*a); self._gutter.yview_moveto(self._text.yview()[0])

    def _update_gutter(self):
        lines=int(self._text.index(tk.END).split(".")[0])
        content="\n".join(str(i) for i in range(1, lines))
        self._gutter.config(state=tk.NORMAL)
        self._gutter.delete("1.0",tk.END)
        self._gutter.insert("1.0",content)
        self._gutter.config(state=tk.DISABLED)

    def _update_status(self):
        try:
            pos=self._text.index(tk.INSERT); ln,col=pos.split(".")
            self._status.config(text=f"  Ln {ln}, Col {int(col)+1}")
        except: pass

    def _update_dirty(self):
        if self._tabs and self._tabs[self._active].dirty:
            self._dirty_lbl.config(text="● unsaved  ")
        else:
            self._dirty_lbl.config(text="")

    def toggle_console_visibility(self): self._toggle_console()
    def clear_console(self): self._clear_console()
