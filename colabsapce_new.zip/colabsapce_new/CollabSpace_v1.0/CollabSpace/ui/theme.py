"""ui/theme.py — design tokens and reusable widget helpers."""
import tkinter as tk
from tkinter import ttk

# ── Colours ───────────────────────────────────────────────────────────────────
BG      = "#0f0f11"
PANEL   = "#16161a"
PANEL2  = "#1c1c21"
BORDER  = "#2a2a35"
TEXT    = "#e8e8f0"
DIM     = "#6b6b80"
ACCENT  = "#7c6af7"
ACCENT2 = "#9580ff"
SUCCESS = "#3dcfb0"
WARN    = "#f0c060"
ERROR   = "#f05060"
BLUE    = "#4a9eff"
PURPLE  = "#c97bf7"
ORANGE  = "#f07840"

PROJ_COLORS = [ACCENT, SUCCESS, WARN, PURPLE, ORANGE, BLUE]

FONT      = ("Segoe UI", 10)
FONT_SM   = ("Segoe UI",  9)
FONT_XS   = ("Segoe UI",  8)
FONT_BOLD = ("Segoe UI", 10, "bold")
FONT_MONO = ("Consolas",  11)
FONT_MONO_SM = ("Consolas", 10)

# ── Helpers ───────────────────────────────────────────────────────────────────
def btn(parent, text, cmd=None, bg=PANEL2, fg=TEXT, abg=ACCENT, afg="white",
        font=FONT_SM, px=10, py=4, cursor="hand2", **kw):
    b = tk.Button(parent, text=text, command=cmd, bg=bg, fg=fg,
                  activebackground=abg, activeforeground=afg,
                  font=font, bd=0, relief=tk.FLAT, cursor=cursor,
                  padx=px, pady=py, **kw)
    b.bind("<Enter>", lambda _: b.config(bg=abg, fg=afg))
    b.bind("<Leave>", lambda _: b.config(bg=bg,  fg=fg))
    return b

def label(parent, text, fg=TEXT, bg=PANEL, font=FONT, **kw):
    return tk.Label(parent, text=text, fg=fg, bg=bg, font=font, **kw)

def separator(parent, bg=BORDER, height=1, fill=tk.X):
    f = tk.Frame(parent, bg=bg, height=height)
    f.pack(fill=fill)
    return f

def section_header(parent, text, bg=PANEL2):
    f = tk.Frame(parent, bg=bg, pady=6)
    f.pack(fill=tk.X)
    tk.Label(f, text=f"  {text}", bg=bg, fg=DIM,
             font=("Segoe UI", 8, "bold")).pack(side=tk.LEFT)
    return f

def scrolled_listbox(parent, bg=PANEL, **kw):
    frame = tk.Frame(parent, bg=bg)
    vsb = tk.Scrollbar(frame, bg=PANEL2, troughcolor=bg, width=8, bd=0)
    vsb.pack(side=tk.RIGHT, fill=tk.Y)
    lb = tk.Listbox(frame, bg=bg, fg=TEXT, font=FONT_SM,
                    selectbackground=ACCENT, selectforeground="white",
                    activestyle="none", bd=0, highlightthickness=0,
                    yscrollcommand=vsb.set, **kw)
    lb.pack(fill=tk.BOTH, expand=True)
    vsb.config(command=lb.yview)
    return frame, lb

def tag_label(parent, text, color=ACCENT, bg=PANEL2):
    return tk.Label(parent, text=text, fg=color,
                    bg=hex_mix(color, bg, 0.15),
                    font=("Segoe UI", 8, "bold"),
                    relief=tk.FLAT, bd=0, padx=6, pady=2)

def hex_mix(hex_color: str, bg_hex: str, alpha: float) -> str:
    """Blend hex_color over bg_hex at alpha."""
    try:
        r1,g1,b1 = int(hex_color[1:3],16),int(hex_color[3:5],16),int(hex_color[5:7],16)
        r2,g2,b2 = int(bg_hex[1:3],16),  int(bg_hex[3:5],16),  int(bg_hex[5:7],16)
        r = int(r1*alpha + r2*(1-alpha))
        g = int(g1*alpha + g2*(1-alpha))
        b = int(b1*alpha + b2*(1-alpha))
        return f"#{r:02x}{g:02x}{b:02x}"
    except Exception:
        return bg_hex

# priority colour
def pri_color(p):
    return {"high":ERROR,"medium":WARN,"low":DIM}.get(p, DIM)

# Status-dot colour
def status_color(s):
    return SUCCESS if s=="online" else WARN

# initials avatar as canvas
def avatar_canvas(parent, initials, color, size=28, bg=PANEL):
    c = tk.Canvas(parent, width=size, height=size, bg=bg,
                  highlightthickness=0, bd=0)
    r = size//2
    fill = hex_mix(color, "#000000", 0.2)
    c.create_oval(1,1,size-1,size-1, fill=fill, outline=color, width=1.5)
    c.create_text(r, r, text=initials, fill=color,
                  font=("Segoe UI", max(7,size//3), "bold"))
    return c

def bind_mousewheel(widget, yview_command):
    """Attach consistent mouse-wheel scrolling for the active widget."""
    def _on_wheel(event):
        delta = 0
        if hasattr(event, "delta") and event.delta:
            delta = -1 if event.delta > 0 else 1
        elif getattr(event, "num", None) == 4:
            delta = -1
        elif getattr(event, "num", None) == 5:
            delta = 1
        if delta:
            yview_command("scroll", delta, "units")
            return "break"
        return None

    widget.bind("<Enter>", lambda _e: widget.bind_all("<MouseWheel>", _on_wheel))
    widget.bind("<Leave>", lambda _e: widget.unbind_all("<MouseWheel>"))
    widget.bind("<Button-4>", _on_wheel)
    widget.bind("<Button-5>", _on_wheel)
# Backwards compatibility shim
def _hex_mix(c1, c2, t):
    return hex_mix(c1, c2, t)