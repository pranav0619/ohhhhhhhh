"""ui/activity_panel.py — activity log view."""
import tkinter as tk
from ui.theme import *
from core.members import get_activity, MEMBERS

TYPE_ICON  = {"edit":"✏", "task":"☑", "note":"📝", "view":"👁", "done":"✔"}
TYPE_COLOR = {"edit": BLUE, "task": WARN, "note": PURPLE, "view": DIM, "done": SUCCESS}

class ActivityPanel(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent, bg=BG)
        self._build()

    def _build(self):
        hdr = tk.Frame(self, bg=PANEL, pady=10)
        hdr.pack(fill=tk.X)
        tk.Label(hdr, text="  Activity Log", bg=PANEL, fg=TEXT,
                 font=("Segoe UI",13,"bold")).pack(side=tk.LEFT, padx=8)
        separator(self)

        wrapper = tk.Frame(self, bg=BG)
        wrapper.pack(fill=tk.BOTH, expand=True)
        vsb = tk.Scrollbar(wrapper, bg=PANEL2, troughcolor=BG, width=8, bd=0)
        vsb.pack(side=tk.RIGHT, fill=tk.Y)
        canvas = tk.Canvas(wrapper, bg=BG, bd=0, highlightthickness=0,
                            yscrollcommand=vsb.set)
        canvas.pack(fill=tk.BOTH, expand=True)
        vsb.config(command=canvas.yview)
        self._inner = tk.Frame(canvas, bg=BG)
        self._win = canvas.create_window((0,0), window=self._inner, anchor=tk.NW)
        self._inner.bind("<Configure>",
                         lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>",
                    lambda e: canvas.itemconfig(self._win, width=e.width))
        bind_mousewheel(canvas, canvas.yview)
        self._canvas = canvas
        self.refresh()

    def refresh(self):
        for w in self._inner.winfo_children(): w.destroy()
        log = get_activity()
        for item in log:
            t    = item.get("type","edit")
            icon  = TYPE_ICON.get(t,"⚡")
            color = TYPE_COLOR.get(t, DIM)

            row = tk.Frame(self._inner, bg=BG)
            row.pack(fill=tk.X, padx=16, pady=0)

            # Icon circle
            ic = tk.Canvas(row, width=32, height=32, bg=BG, bd=0, highlightthickness=0)
            ic.pack(side=tk.LEFT, pady=6, padx=(0,10))
            ic.create_oval(4,4,28,28, fill=hex_mix(color,BG,0.2), outline=color, width=1)
            ic.create_text(16,16, text=icon, fill=color, font=("Segoe UI",10))

            # Text
            tf = tk.Frame(row, bg=BG)
            tf.pack(side=tk.LEFT, fill=tk.X, expand=True, pady=8)

            trow = tk.Frame(tf, bg=BG)
            trow.pack(fill=tk.X)
            tk.Label(trow, text=item["user"], bg=BG, fg=ACCENT,
                     font=("Segoe UI",9,"bold")).pack(side=tk.LEFT)
            tk.Label(trow, text=f"  {item['action']}", bg=BG, fg=DIM,
                     font=FONT_SM).pack(side=tk.LEFT)

            # Time
            tk.Label(row, text=item["time"], bg=BG, fg=DIM,
                     font=FONT_XS).pack(side=tk.RIGHT, pady=8, padx=8)

            # Divider
            tk.Frame(self._inner, bg=BORDER, height=1).pack(fill=tk.X, padx=16)
