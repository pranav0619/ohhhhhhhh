"""ui/team_panel.py — team members view."""
import tkinter as tk
from tkinter import messagebox
from ui.theme import *
from core.members import get_members, member_by_id, remove_member

class TeamPanel(tk.Frame):
    def __init__(self, parent, task_manager, get_project, on_update=None):
        super().__init__(parent, bg=BG)
        self._tm = task_manager
        self._get_proj = get_project
        self._on_update = on_update
        self._build()

    def _build(self):
        # Header
        hdr = tk.Frame(self, bg=PANEL, pady=10)
        hdr.pack(fill=tk.X)
        tk.Label(hdr, text="  Team Members", bg=PANEL, fg=TEXT,
                 font=("Segoe UI",13,"bold")).pack(side=tk.LEFT, padx=8)
        self._count_label = tk.Label(hdr, text=f"{len(get_members())} members",
                                     bg=hex_mix(SUCCESS,PANEL,0.2), fg=SUCCESS,
                                     font=("Segoe UI",8,"bold"), padx=8, pady=3)
        self._count_label.pack(side=tk.LEFT, padx=6)
        separator(self)

        # Scrollable content
        wrapper = tk.Frame(self, bg=BG)
        wrapper.pack(fill=tk.BOTH, expand=True)
        vsb = tk.Scrollbar(wrapper, bg=PANEL2, troughcolor=BG, width=8, bd=0)
        vsb.pack(side=tk.RIGHT, fill=tk.Y)
        canvas = tk.Canvas(wrapper, bg=BG, bd=0, highlightthickness=0,
                            yscrollcommand=vsb.set)
        canvas.pack(fill=tk.BOTH, expand=True)
        vsb.config(command=canvas.yview)
        bind_mousewheel(canvas, canvas.yview)
        self._inner = tk.Frame(canvas, bg=BG)
        win = canvas.create_window((0,0), window=self._inner, anchor=tk.NW)
        self._inner.bind("<Configure>",
                         lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>",
                    lambda e: canvas.itemconfig(win, width=e.width))

        self._render()

    def _render(self):
        for w in self._inner.winfo_children(): w.destroy()
        proj = self._get_proj()
        members = get_members()
        self._count_label.config(text=f"{len(members)} members")

        if not members:
            tk.Label(self._inner, text="No team members configured yet.", bg=BG, fg=DIM,
                     font=FONT_SM, pady=20).pack()
            return

        grid = tk.Frame(self._inner, bg=BG)
        grid.pack(fill=tk.X, padx=16, pady=16)
        grid.columnconfigure(0, weight=1)
        grid.columnconfigure(1, weight=1)

        tasks = (self._tm.for_project(proj.pid) if proj else [])

        for i, m in enumerate(members):
            mtasks = [t for t in tasks if t.assignee == m["id"]]
            done   = [t for t in mtasks if t.status == "done"]

            card = tk.Frame(grid, bg=PANEL2, relief=tk.FLAT, bd=0)
            card.grid(row=i//2, column=i%2, padx=6, pady=6, sticky="nsew")

            inner = tk.Frame(card, bg=PANEL2, padx=14, pady=12)
            inner.pack(fill=tk.BOTH, expand=True)

            top = tk.Frame(inner, bg=PANEL2)
            top.pack(fill=tk.X, pady=(0,8))
            av = avatar_canvas(top, m["avatar"], m["color"], size=40, bg=PANEL2)
            av.pack(side=tk.LEFT, padx=(0,10))
            info = tk.Frame(top, bg=PANEL2)
            info.pack(side=tk.LEFT, fill=tk.X, expand=True)
            tk.Label(info, text=m["name"], bg=PANEL2, fg=TEXT,
                     font=("Segoe UI",10,"bold")).pack(anchor=tk.W)
            tk.Label(info, text=m["role"], bg=PANEL2, fg=m["color"],
                     font=FONT_SM).pack(anchor=tk.W)
            tk.Button(top, text="Remove", bg=ERROR, fg="white", bd=0, relief=tk.FLAT,
                      cursor="hand2", command=lambda uid=m["id"]: self._remove_member(uid)).pack(side=tk.RIGHT)

            sf = tk.Frame(inner, bg=PANEL2)
            sf.pack(fill=tk.X, pady=(0,6))
            tk.Label(sf, text="●", bg=PANEL2, fg=status_color(m["status"]),
                     font=FONT_XS).pack(side=tk.LEFT)
            tk.Label(sf, text=f"  {m['status'].capitalize()}  —  {m['task']}",
                     bg=PANEL2, fg=DIM, font=FONT_XS).pack(side=tk.LEFT)

            tf = tk.Frame(inner, bg=PANEL2)
            tf.pack(fill=tk.X)
            for txt, color in [(f"{len(mtasks)} tasks", ACCENT),
                               (f"{len(done)} done", SUCCESS),
                               (m["status"], status_color(m["status"]))]:
                tk.Label(tf, text=txt,
                         bg=hex_mix(color, PANEL2, 0.15), fg=color,
                         font=("Segoe UI",8,"bold"), padx=6, pady=2,
                         relief=tk.FLAT).pack(side=tk.LEFT, padx=(0,5))

            if mtasks:
                pct = len(done)/len(mtasks)
                pb_bg = tk.Frame(inner, bg=BORDER, height=4)
                pb_bg.pack(fill=tk.X, pady=(8,0))
                pb_bg.pack_propagate(False)
                pb_fill = tk.Frame(pb_bg, bg=SUCCESS, height=4)
                pb_fill.place(relwidth=pct, relheight=1.0)

    def _remove_member(self, uid):
        from core.members import remove_member
        remove_member(uid)
        self._render()
        if self._on_update:
            self._on_update()
    def refresh(self):
        self._render()
