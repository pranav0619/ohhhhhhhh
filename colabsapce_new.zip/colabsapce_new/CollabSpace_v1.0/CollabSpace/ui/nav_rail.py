"""ui/nav_rail.py — icon navigation sidebar."""
import tkinter as tk
from ui.theme import *

NAV_ITEMS = [
    ("editor",   "⟨/⟩", "Editor"),
    ("tasks",    "☑",   "Tasks"),
    ("notes",    "📝",   "Notes"),
    ("members",  "👥",   "Team"),
    ("activity", "⚡",   "Activity"),
    ("settings", "⚙",   "Settings"),
]

class NavRail(tk.Frame):
    def __init__(self, parent, on_select):
        super().__init__(parent, bg=PANEL, width=52)
        self.pack_propagate(False)
        self._on_select = on_select
        self._active = "editor"
        self._btns = {}
        self._build()

    def _build(self):
        tk.Frame(self, bg=PANEL, height=8).pack()
        for key, icon, tip in NAV_ITEMS:
            f = tk.Frame(self, bg=PANEL, width=52, height=44)
            f.pack_propagate(False)
            f.pack(pady=1)
            b = tk.Label(f, text=icon, bg=PANEL, fg=DIM,
                         font=("Segoe UI",15), cursor="hand2", width=3)
            b.place(relx=0.5, rely=0.5, anchor=tk.CENTER)
            b.bind("<Button-1>", lambda e, k=key: self.select(k))
            b.bind("<Enter>",    lambda e, b=b, k=key: self._hover(b, k, True))
            b.bind("<Leave>",    lambda e, b=b, k=key: self._hover(b, k, False))
            # tooltip
            _Tooltip(b, tip)
            self._btns[key] = (f, b)
        # self.select("editor")  # removed to avoid calling before panels are ready

    def select(self, key):
        if self._active == key:
            return
        self._active = key
        for k, (f, b) in self._btns.items():
            if k == key:
                f.config(bg=hex_mix(ACCENT, PANEL, 0.15))
                b.config(bg=hex_mix(ACCENT, PANEL, 0.15), fg=ACCENT)
            else:
                f.config(bg=PANEL)
                b.config(bg=PANEL, fg=DIM)
        self._on_select(key)

class _Tooltip:
    def __init__(self, widget, text):
        self._text = text
        self._tip = None
        widget.bind("<Enter>", self._show)
        widget.bind("<Leave>", self._hide)

    def _show(self, event):
        x = event.widget.winfo_rootx() + 54
        y = event.widget.winfo_rooty() + 8
        self._tip = tk.Toplevel(event.widget)
        self._tip.wm_overrideredirect(True)
        self._tip.wm_geometry(f"+{x}+{y}")
        tk.Label(self._tip, text=self._tip_text(), bg=BORDER, fg=TEXT,
                 font=FONT_SM, padx=8, pady=4).pack()

    def _tip_text(self): return self._text
    def _hide(self, _=None):
        if self._tip: self._tip.destroy(); self._tip = None
