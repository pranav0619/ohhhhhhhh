"""ui/right_panel.py — right-side stats & info sidebar."""
import tkinter as tk
from ui.theme import *
from core.members import get_members, get_activity

class RightPanel(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent, bg=PANEL, width=240)
        self.pack_propagate(False)
        self._build()

    def _build(self):
        # Project overview section
        self._overview_frame = tk.Frame(self, bg=PANEL, padx=14, pady=12)
        self._overview_frame.pack(fill=tk.X)

        tk.Label(self._overview_frame, text="PROJECT OVERVIEW",
                 bg=PANEL, fg=DIM, font=("Segoe UI",8,"bold")).pack(anchor=tk.W, pady=(0,8))

        self._proj_name = tk.Label(self._overview_frame, text="No project",
                                    bg=PANEL, fg=TEXT, font=("Segoe UI",11,"bold"),
                                    wraplength=200, justify=tk.LEFT)
        self._proj_name.pack(anchor=tk.W)
        self._proj_desc = tk.Label(self._overview_frame, text="",
                                    bg=PANEL, fg=DIM, font=FONT_SM,
                                    wraplength=200, justify=tk.LEFT)
        self._proj_desc.pack(anchor=tk.W, pady=(2,8))

        # Progress bar
        prog_lbl_f = tk.Frame(self._overview_frame, bg=PANEL)
        prog_lbl_f.pack(fill=tk.X)
        tk.Label(prog_lbl_f, text="Progress", bg=PANEL, fg=DIM, font=FONT_XS).pack(side=tk.LEFT)
        self._pct_lbl = tk.Label(prog_lbl_f, text="0%", bg=PANEL, fg=DIM, font=FONT_XS)
        self._pct_lbl.pack(side=tk.RIGHT)
        self._prog_bg = tk.Frame(self._overview_frame, bg=BORDER, height=5)
        self._prog_bg.pack(fill=tk.X, pady=(3,10))
        self._prog_fill = tk.Frame(self._prog_bg, bg=ACCENT, height=5)
        self._prog_fill.place(relwidth=0, relheight=1)

        # Stats grid
        self._stats_grid = tk.Frame(self._overview_frame, bg=PANEL)
        self._stats_grid.pack(fill=tk.X)
        self._stats_grid.columnconfigure(0, weight=1)
        self._stats_grid.columnconfigure(1, weight=1)
        self._stat_vals = {}
        for i, (key, icon, label) in enumerate([
            ("files",   "📄", "Files"),
            ("tasks",   "☑",  "Tasks"),
            ("done",    "✅",  "Done"),
            ("members", "👥",  "Members"),
        ]):
            card = tk.Frame(self._stats_grid, bg=PANEL2, padx=8, pady=8)
            card.grid(row=i//2, column=i%2, padx=4, pady=4, sticky="nsew")
            tk.Label(card, text=icon, bg=PANEL2, fg=TEXT, font=("Segoe UI",14)).pack()
            v = tk.Label(card, text="0", bg=PANEL2, fg=TEXT, font=("Segoe UI",16,"bold"))
            v.pack()
            tk.Label(card, text=label, bg=PANEL2, fg=DIM, font=FONT_XS).pack()
            self._stat_vals[key] = v

    def update_stats(self, proj, files, tasks, done, members):
        if proj:
            self._proj_name.config(text=proj.name, fg=proj.color)
            self._proj_desc.config(text=proj.desc or "No description")
        else:
            self._proj_name.config(text="No project selected", fg=DIM)
            self._proj_desc.config(text="")

        pct = int(done/tasks*100) if tasks else 0
        self._pct_lbl.config(text=f"{pct}%")
        color = SUCCESS if pct==100 else ACCENT
        self._prog_fill.place(relwidth=pct/100, relheight=1)
        self._prog_fill.config(bg=color)

        for key, val in [("files",files),("tasks",tasks),("done",done),("members",members)]:
            self._stat_vals[key].config(text=str(val))
