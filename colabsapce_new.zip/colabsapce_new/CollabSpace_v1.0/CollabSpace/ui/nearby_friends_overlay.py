import tkinter as tk
from ui.theme import PANEL2, TEXT, DIM, ACCENT, SUCCESS, btn


class NearbyFriendsOverlay:
    def __init__(self, parent, on_add_to_team, on_dismiss):
        self._parent = parent
        self._on_add_to_team = on_add_to_team
        self._on_dismiss = on_dismiss
        self._cards = {}

    def show_friend(self, friend_hash: str, info: dict):
        if friend_hash in self._cards:
            return
        card = tk.Frame(self._parent, bg=PANEL2, highlightthickness=1, highlightbackground=ACCENT)
        y = 80 + (len(self._cards) * 110)
        card.place(relx=1.0, x=-16, y=y, anchor="ne", width=280, height=98)
        tk.Label(card, text=info.get("display_name", "Friend"), bg=PANEL2, fg=TEXT, font=("Segoe UI", 10, "bold")).pack(anchor=tk.W, padx=10, pady=(8, 2))
        tk.Label(card, text="Nearby on WiFi", bg=PANEL2, fg=SUCCESS, font=("Segoe UI", 8, "bold")).pack(anchor=tk.W, padx=10)
        tk.Label(card, text=info.get("device_name", ""), bg=PANEL2, fg=DIM, font=("Segoe UI", 8)).pack(anchor=tk.W, padx=10, pady=(0, 4))
        actions = tk.Frame(card, bg=PANEL2)
        actions.pack(fill=tk.X, padx=10, pady=(2, 8))
        btn(actions, "Add to Team", lambda h=friend_hash, i=info: self._on_add_to_team(h, i), bg=ACCENT, fg="white").pack(side=tk.LEFT)
        btn(actions, "X", lambda h=friend_hash: self.dismiss(h), bg=PANEL2, fg=DIM).pack(side=tk.RIGHT)
        self._cards[friend_hash] = card
        card.after(30000, lambda h=friend_hash: self.dismiss(h))

    def dismiss(self, friend_hash: str):
        card = self._cards.pop(friend_hash, None)
        if card:
            card.destroy()
            self._on_dismiss(friend_hash)
            self._reflow()

    def mark_offline(self, friend_hash: str, name: str):
        card = self._cards.get(friend_hash)
        if not card:
            return
        for w in card.winfo_children():
            if isinstance(w, tk.Label) and w.cget("text") == "Nearby on WiFi":
                w.config(text=f"{name} went offline", fg=DIM)

    def _reflow(self):
        for idx, card in enumerate(self._cards.values()):
            y = 80 + (idx * 110)
            card.place_configure(y=y)
