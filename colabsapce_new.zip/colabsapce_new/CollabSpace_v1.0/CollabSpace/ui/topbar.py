"""ui/topbar.py — top navigation bar."""
import tkinter as tk
from ui.theme import *
class TopBar(tk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent, bg=PANEL2, height=48)
        self.pack_propagate(False)
        self._app = app
        self._proj_btns = {}
        self._build()

    def _build(self):
        # Logo
        logo = tk.Frame(self, bg=ACCENT, width=32, height=32)
        logo.pack_propagate(False)
        logo.pack(side=tk.LEFT, padx=(12,6), pady=8)
        tk.Label(logo, text="⟨⟩", bg=ACCENT, fg="white",
                 font=("Segoe UI",12,"bold")).pack(expand=True)

        tk.Label(self, text="CollabSpace", bg=PANEL2, fg=TEXT,
                 font=("Segoe UI",13,"bold")).pack(side=tk.LEFT, padx=(0,4))
        tk.Label(self, text="v1.0", bg=hex_mix(ACCENT,PANEL2,0.2), fg=ACCENT,
                 font=("Segoe UI",8,"bold"), padx=5, pady=2).pack(side=tk.LEFT, padx=4)

        sep = tk.Frame(self, bg=BORDER, width=1, height=28)
        sep.pack(side=tk.LEFT, padx=10)

        # Project tabs frame
        self._tabs_frame = tk.Frame(self, bg=PANEL2)
        self._tabs_frame.pack(side=tk.LEFT, fill=tk.Y)

        # New project button
        btn(self, "+ New Project", self._app.new_project,
            bg=PANEL2, fg=DIM, abg=PANEL, afg=TEXT,
            font=FONT_XS).pack(side=tk.LEFT, padx=4)

        self._spacer = tk.Frame(self, bg=PANEL2)
        self._spacer.pack(side=tk.LEFT, fill=tk.X, expand=True)

        # Stats
        self._stats_var = tk.StringVar(value="")
        tk.Label(self, textvariable=self._stats_var, bg=PANEL2,
                 fg=DIM, font=FONT_XS).pack(side=tk.LEFT, padx=12)

        # Online avatars
        self._avatar_frame = tk.Frame(self, bg=PANEL2)
        self._avatar_frame.pack(side=tk.RIGHT, padx=12)

    def refresh_projects(self, projects, active_pid):
        for w in self._tabs_frame.winfo_children(): w.destroy()
        self._proj_btns.clear()
        for p in reversed(projects):
            is_active = p.pid == active_pid
            bg  = hex_mix(p.color, PANEL2, 0.15) if is_active else PANEL2
            fg  = p.color if is_active else DIM
            b   = tk.Button(self._tabs_frame, text=f"  {p.name}  ",
                            bg=bg, fg=fg, activebackground=hex_mix(p.color,PANEL2,0.25),
                            activeforeground=p.color,
                            font=("Segoe UI",9,"bold") if is_active else FONT_SM,
                            bd=0, relief=tk.FLAT, cursor="hand2",
                            pady=0,
                            command=lambda pid=p.pid: self._app.switch_project(pid))
            if is_active:
                b.config(relief=tk.FLAT)
            b.pack(side=tk.LEFT, fill=tk.Y)
            self._proj_btns[p.pid] = b

    def set_stats(self, files, tasks, done, members):
        self._stats_var.set(f"📄 {files} files   ☑ {done}/{tasks} tasks   👥 {members}")

    def set_avatars(self, members):
        for w in self._avatar_frame.winfo_children(): w.destroy()
        for m in members:
            if m["status"]=="online":
                av = avatar_canvas(self._avatar_frame, m["avatar"], m["color"], size=26, bg=PANEL2)
                av.pack(side=tk.LEFT, padx=2)
