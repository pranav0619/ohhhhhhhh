"""ui/syntax.py — lightweight syntax highlighting for tk.Text."""
import re

RULES = {
    "py": [
        (r'"""[\s\S]*?"""',        "string"),
        (r"'''[\s\S]*?'''",        "string"),
        (r'#[^\n]*',               "comment"),
        (r'"[^"\\]*(?:\\.[^"\\]*)*"', "string"),
        (r"'[^'\\]*(?:\\.[^'\\]*)*'", "string"),
        (r'\b(if|elif|else|for|while|break|continue|return|yield|pass|raise|'
         r'try|except|finally|with|as|and|or|not|in|is)\b', "kw"),
        (r'\b(def|class|lambda|async|await)\b',              "kwd"),
        (r'\b(import|from)\b',                               "kwi"),
        (r'\b(print|len|range|type|isinstance|int|str|float|list|dict|set|'
         r'tuple|bool|None|True|False|self|super)\b',        "kwb"),
        (r'\b\d+(\.\d+)?\b',                                 "num"),
        (r'@\w+',                                            "dec"),
    ],
    "js": [
        (r'//[^\n]*',               "comment"),
        (r'/\*[\s\S]*?\*/',         "comment"),
        (r'"[^"\\]*(?:\\.[^"\\]*)*"', "string"),
        (r"'[^'\\]*(?:\\.[^'\\]*)*'", "string"),
        (r'`[^`\\]*(?:\\.[^`\\]*)*`', "string"),
        (r'\b(if|else|for|while|do|switch|case|default|break|continue|return|'
         r'try|catch|finally|throw|with|in|instanceof|typeof|new|delete|void)\b', "kw"),
        (r'\b(function|class|const|let|var|async|await|export|import)\b', "kwd"),
        (r'\b(console|log|alert|document|window|Math|Array|Object|String|Number|'
         r'Boolean|RegExp|Date|JSON|Promise|setTimeout|setInterval)\b', "kwb"),
        (r'\b\d+(\.\d+)?\b',         "num"),
        (r'/\w+',                    "dec"),  # regex, but simple
    ],
    "html": [
        (r'<!--[\s\S]*?-->',        "comment"),
        (r'"[^"]*"',                "string"),
        (r"'[^']*'",                "string"),
        (r'<[^>]+>',                "tag"),
        (r'\b\d+(\.\d+)?\b',        "num"),
    ]
}

TAG_CFG = {
    "kw":      {"foreground":"#c586c0"},
    "kwd":     {"foreground":"#569cd6"},
    "kwi":     {"foreground":"#c586c0"},
    "kwb":     {"foreground":"#4ec9b0"},
    "string":  {"foreground":"#ce9178"},
    "comment": {"foreground":"#6a9955","font":("Consolas",11,"italic")},
    "num":     {"foreground":"#b5cea8"},
    "dec":     {"foreground":"#dcdcaa"},
    "tag":     {"foreground":"#569cd6"},
}

def setup_tags(text_widget):
    for tag, cfg in TAG_CFG.items():
        text_widget.tag_config(tag, **cfg)

def highlight(text_widget, lang="py"):
    lang = lang.lower()
    if lang not in RULES: lang = "py"
    rules = RULES[lang]
    code = text_widget.get("1.0", "end-1c")
    for tag in TAG_CFG:
        text_widget.tag_remove(tag, "1.0", "end")
    used = [False]*len(code)
    spans = []
    for pattern, tag in rules:
        for m in re.finditer(pattern, code, re.MULTILINE):
            s,e = m.start(), m.end()
            if any(used[s:e]): continue
            spans.append((s,e,tag))
            for i in range(s,e): used[i]=True
    for s,e,tag in spans:
        text_widget.tag_add(tag,
                            f"1.0+{s}c",
                            f"1.0+{e}c")
