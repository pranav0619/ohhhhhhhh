"""ui/file_tree.py — left file-explorer panel."""
import tkinter as tk
from tkinter import messagebox
from ui.theme import *
from core.members import get_members
from ui.dialogs import ask_text

class FileTree(tk.Frame):
    def __init__(self, parent, file_manager, on_open):
        super().__init__(parent, bg=PANEL, width=220)
        self.pack_propagate(False)
        self._fm = file_manager
        self._on_open = on_open
        self._project = None
        self._selected = None
        self._rows = {}
        self._hover = None
        self._build()

    def _build(self):
        # Header
        hdr = tk.Frame(self, bg=PANEL2, pady=8)
        hdr.pack(fill=tk.X)
        tk.Label(hdr, text="  FILES", bg=PANEL2, fg=DIM,
                 font=("Segoe UI",8,"bold")).pack(side=tk.LEFT)
        btn(hdr, "+ New", self._new_file, bg=PANEL2, fg=ACCENT,
            abg=hex_mix(ACCENT,PANEL2,0.2), afg=ACCENT,
            font=("Segoe UI",8), px=6, py=2).pack(side=tk.RIGHT, padx=4)

        # Search
        sf = tk.Frame(self, bg=PANEL, pady=4)
        sf.pack(fill=tk.X, padx=8)
        self._search_var = tk.StringVar()
        e = tk.Entry(sf, textvariable=self._search_var, bg=PANEL2,
                     fg=TEXT, insertbackground=TEXT, relief=tk.FLAT,
                     font=FONT_SM, bd=4)
        e.pack(fill=tk.X)
        e.insert(0, "Search files…")
        self._search_var.trace_add("write", lambda *_: self._filter())
        e.bind("<FocusIn>",  lambda _: e.delete(0,tk.END) if e.get()=="Search files…" else None)
        e.bind("<FocusOut>", lambda _: (e.insert(0,"Search files…") if not e.get() else None))

        separator(self)

        # Scrollable list
        wrapper = tk.Frame(self, bg=PANEL)
        wrapper.pack(fill=tk.BOTH, expand=True)
        vsb = tk.Scrollbar(wrapper, bg=PANEL2, troughcolor=PANEL, width=6, bd=0)
        vsb.pack(side=tk.RIGHT, fill=tk.Y)
        self._canvas = tk.Canvas(wrapper, bg=PANEL, bd=0, highlightthickness=0,
                                  yscrollcommand=vsb.set)
        self._canvas.pack(fill=tk.BOTH, expand=True)
        vsb.config(command=self._canvas.yview)
        bind_mousewheel(self._canvas, self._canvas.yview)
        self._list = tk.Frame(self._canvas, bg=PANEL)
        self._win  = self._canvas.create_window((0,0), window=self._list, anchor=tk.NW)
        self._list.bind("<Configure>",
                        lambda e: self._canvas.configure(scrollregion=self._canvas.bbox("all")))
        self._canvas.bind("<Configure>",
                          lambda e: self._canvas.itemconfig(self._win, width=e.width))

        separator(self)

        # Online members quick-view
        self._members_frame = tk.Frame(self, bg=PANEL, pady=4)
        self._members_frame.pack(fill=tk.X)
        tk.Label(self._members_frame, text="  ONLINE", bg=PANEL, fg=DIM,
                 font=("Segoe UI",8,"bold")).pack(anchor=tk.W, padx=4)
        self._render_online_members()

    def _render_online_members(self):
        # Clear existing
        for w in self._members_frame.winfo_children():
            if w != self._members_frame.winfo_children()[0]:  # keep the label
                w.destroy()
        # Add online members
        for m in get_members():
            if m["status"] == "online":
                row = tk.Frame(self._members_frame, bg=PANEL)
                row.pack(fill=tk.X, padx=8, pady=2)
                av = avatar_canvas(row, m["avatar"], m["color"], size=20, bg=PANEL)
                av.pack(side=tk.LEFT, padx=(0,5))
                tf = tk.Frame(row, bg=PANEL)
                tf.pack(side=tk.LEFT, fill=tk.X, expand=True)
                tk.Label(tf, text=m["name"].split()[0], bg=PANEL, fg=TEXT,
                         font=("Segoe UI",9,"bold"), anchor=tk.W).pack(fill=tk.X)
                tk.Label(tf, text=m["task"], bg=PANEL, fg=DIM,
                         font=("Segoe UI",8), anchor=tk.W).pack(fill=tk.X)

    def _open_file(self, name):
        try:
            content = self._fm.read(name)
            self._selected = name
            self._on_open(name, content)
            self.refresh()  # to update highlight
        except Exception as e:
            # Maybe show error
            pass

    def set_project(self, project):
        self._project = project
        if project:
            # Use the explicit selected project path to store files correctly
            self._fm.set_project(project.pid, project.path)
        self.refresh()

    def refresh(self):
        for w in self._list.winfo_children(): w.destroy()
        self._rows.clear(); self._selected = None
        self._render_online_members()
        if not self._project:
            tk.Label(self._list, text="Select a project\nto see its files.",
                     bg=PANEL, fg=DIM, font=FONT_SM, justify=tk.CENTER,
                     pady=20).pack()
            return
        files = self._fm.list_files()
        q = self._search_var.get()
        if q and q != "Search files…":
            files = [f for f in files if q.lower() in f["name"].lower()]
        if not files:
            tk.Label(self._list, text="No files yet.\nClick + New to create one.",
                     bg=PANEL, fg=DIM, font=FONT_SM, justify=tk.CENTER,
                     pady=20).pack()
            return
        for info in files:
            self._render_row(info)

    def _filter(self): self.refresh()

    def _render_row(self, info):
        name  = info["name"]
        icon  = info["icon"]
        is_active = (name == self._selected)

        # Check if a member is editing this file
        editor = next((m for m in get_members() if name in m.get("task","")), None)

        row = tk.Frame(self._list, bg=PANEL, cursor="hand2")
        row.pack(fill=tk.X)
        self._rows[name] = row

        indicator = tk.Frame(row, bg=ACCENT if is_active else PANEL, width=3)
        indicator.pack(side=tk.LEFT, fill=tk.Y)

        tk.Label(row, text=f" {icon} ", bg=PANEL, fg=ACCENT,
                 font=("Segoe UI",10)).pack(side=tk.LEFT)
        name_label = tk.Label(row, text=name, bg=PANEL, fg=TEXT if is_active else DIM,
                 font=("Segoe UI",9,"bold") if is_active else FONT_SM,
                 anchor=tk.W)
        name_label.pack(side=tk.LEFT, fill=tk.X, expand=True)
        name_label.bind("<Button-1>", lambda e, n=name: self._open_file(n))

        if editor:
            dot = tk.Label(row, text="●", bg=PANEL, fg=editor["color"],
                           font=("Segoe UI",8))
            dot.pack(side=tk.RIGHT, padx=2)

        # Delete button (hidden until hover)
        del_btn = tk.Label(row, text="✕", bg=PANEL, fg=DIM,
                           font=("Segoe UI",9), cursor="hand2", padx=4)

        for w in (row, indicator):
            w.bind("<Button-1>",       lambda e, n=name: self._click(n))
            w.bind("<Double-Button-1>",lambda e, n=name: self._dbl(n))
            w.bind("<Button-3>",       lambda e, n=name: self._ctx(e, n))
            w.bind("<Enter>",          lambda e, n=name, r=row, d=del_btn, i=indicator: self._enter(n, r, d, i))
            w.bind("<Leave>",          lambda e, n=name, r=row, d=del_btn, i=indicator: self._leave(n, r, d, i))
        del_btn.bind("<Button-1>",     lambda e, n=name: self._delete(n))

    def _click(self, name): self._select(name)
    def _dbl(self, name):   self._select(name); self._open(name)

    def _enter(self, name, row, del_btn, indicator):
        bg = hex_mix(ACCENT, PANEL, 0.1) if name==self._selected else PANEL2
        row.config(bg=bg)
        for w in row.winfo_children(): w.config(bg=bg)
        del_btn.pack(side=tk.RIGHT, padx=4)
        del_btn.config(bg=bg)

    def _leave(self, name, row, del_btn, indicator):
        bg = hex_mix(ACCENT, PANEL, 0.15) if name==self._selected else PANEL
        row.config(bg=bg)
        for w in row.winfo_children(): w.config(bg=bg)
        del_btn.pack_forget()

    def _select(self, name):
        old = self._selected
        self._selected = name
        if old and old in self._rows:
            r = self._rows[old]
            r.config(bg=PANEL)
            for w in r.winfo_children(): w.config(bg=PANEL)
            if r.winfo_children():
                r.winfo_children()[0].config(bg=PANEL)
        if name in self._rows:
            r = self._rows[name]
            bg = hex_mix(ACCENT, PANEL, 0.15)
            r.config(bg=bg)
            for w in r.winfo_children(): w.config(bg=bg)
            if r.winfo_children():
                r.winfo_children()[0].config(bg=ACCENT)

    def _open(self, name):
        try:
            content = self._fm.read(name)
            self._on_open(name, content)
        except Exception as e:
            messagebox.showerror("Open Error", str(e))

    def _ctx(self, event, name):
        self._select(name)
        menu = tk.Menu(self, tearoff=False, bg=PANEL2, fg=TEXT,
                       activebackground=ACCENT, activeforeground="white")
        menu.add_command(label="Open",   command=lambda: self._open(name))
        menu.add_command(label="Rename", command=lambda: self._rename(name))
        menu.add_separator()
        menu.add_command(label="Delete", command=lambda: self._delete(name))
        menu.tk_popup(event.x_root, event.y_root)

    def _new_file(self):
        if not self._project:
            messagebox.showinfo("No Project", "Select a project first."); return
        name = ask_text(self, "New File", "File name (e.g. main.py):")
        if not name: return
        try:
            info = self._fm.create(name.strip())
            self.refresh()
            self._select(info["name"])
            self._on_open(info["name"], "")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def notify_save(self, name, content):
        if not self._project: return
        try:
            if self._fm.exists(name): self._fm.write(name, content)
            else:                     self._fm.create(name, content)
            self.refresh(); self._select(name)
        except Exception as e:
            messagebox.showerror("Save Error", str(e))

    def _rename(self, name):
        new = ask_text(self, "Rename File", "Enter new file name:", initialvalue=name)
        if not new or new.strip()==name: return
        try: self._fm.rename(name, new.strip()); self.refresh()
        except Exception as e: messagebox.showerror("Rename Error", str(e))

    def _delete(self, name):
        if not messagebox.askyesno("Delete", f"Permanently delete '{name}'?"): return
        try: self._fm.delete(name); self._selected=None; self.refresh()
        except Exception as e: messagebox.showerror("Delete Error", str(e))
