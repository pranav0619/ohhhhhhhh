"""ui/terminal_panel.py — integrated terminal like VS Code."""
import tkinter as tk
import subprocess
import threading
import sys
from ui.theme import *

class TerminalPanel(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent, bg=BG)
        self._proc = None
        self._thread = None
        self._running = False
        self._build()
        self._start_shell()

    def _build(self):
        # Terminal area
        term_frame = tk.Frame(self, bg=BG)
        term_frame.pack(fill=tk.BOTH, expand=True)

        # Scrollbar
        vsb = tk.Scrollbar(term_frame, bg=PANEL2, troughcolor=BG, width=8, bd=0)
        vsb.pack(side=tk.RIGHT, fill=tk.Y)

        self._text = tk.Text(term_frame, bg="#09090d", fg="#cccccc",
                             font=("Consolas", 10), bd=0, relief=tk.FLAT,
                             wrap=tk.WORD, padx=10, pady=6,
                             yscrollcommand=vsb.set)
        self._text.pack(fill=tk.BOTH, expand=True)
        vsb.config(command=self._text.yview)

        self._text.tag_config("prompt", foreground="#4ec9b0")
        self._text.tag_config("error", foreground="#f44747")
        self._text.insert(tk.END, "CollabSpace Terminal\n", "prompt")
        self._text.config(state=tk.DISABLED)

        # Input area
        input_frame = tk.Frame(self, bg=PANEL, pady=4)
        input_frame.pack(fill=tk.X, side=tk.BOTTOM)

        tk.Label(input_frame, text=" $ ", bg=PANEL, fg="#4ec9b0", font=("Consolas", 10)).pack(side=tk.LEFT)
        self._entry = tk.Entry(input_frame, bg=BORDER, fg=TEXT, insertbackground=TEXT,
                               relief=tk.FLAT, bd=4, font=("Consolas", 10))
        self._entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=4)
        self._entry.bind("<Return>", self._send_command)
        self._entry.focus()

    def _start_shell(self):
        try:
            # Use PowerShell on Windows
            self._proc = subprocess.Popen(
                ['powershell'],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                cwd=None  # or set to project dir
            )
            self._running = True
            self._thread = threading.Thread(target=self._read_output, daemon=True)
            self._thread.start()
        except Exception as e:
            self._append_output(f"Failed to start shell: {e}\n", "error")

    def _read_output(self):
        while self._running and self._proc:
            try:
                line = self._proc.stdout.readline()
                if line:
                    self.after(0, self._append_output, line)
                elif self._proc.poll() is not None:
                    break
            except:
                break
        self._running = False

    def _append_output(self, text, tag=None):
        self._text.config(state=tk.NORMAL)
        self._text.insert(tk.END, text, tag)
        self._text.see(tk.END)
        self._text.config(state=tk.DISABLED)

    def _send_command(self, event=None):
        cmd = self._entry.get().strip()
        if not cmd:
            return
        self._entry.delete(0, tk.END)
        if self._proc and self._running:
            try:
                self._proc.stdin.write(cmd + '\n')
                self._proc.stdin.flush()
            except Exception as e:
                self._append_output(f"Error sending command: {e}\n", "error")
        else:
            self._append_output("Shell not running\n", "error")

    def destroy(self):
        self._running = False
        if self._proc:
            try:
                self._proc.terminate()
            except:
                pass
        super().destroy()