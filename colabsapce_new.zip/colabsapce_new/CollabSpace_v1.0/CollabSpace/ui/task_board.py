"""ui/task_board.py — Kanban task board panel."""
import tkinter as tk
from tkinter import messagebox, simpledialog
from ui.theme import *
from core.task_manager import TODO, IN_PROG, DONE
from core.members import get_members, member_by_id

COLUMNS = [
    (TODO,    "To Do",       BLUE),
    (IN_PROG, "In Progress", WARN),
    (DONE,    "Done",        SUCCESS),
]

class TaskBoard(tk.Frame):
    def __init__(self, parent, task_manager, get_project):
        super().__init__(parent, bg=BG)
        self._tm = task_manager
        self._get_proj = get_project
        self._col_frames = {}
        self._count_lbls = {}
        self._build()

    def _build(self):
        # Header
        hdr = tk.Frame(self, bg=PANEL, pady=10)
        hdr.pack(fill=tk.X, padx=0)
        tk.Label(hdr, text="  Task Board", bg=PANEL, fg=TEXT,
                 font=("Segoe UI",13,"bold")).pack(side=tk.LEFT, padx=8)
        btn(hdr, "+ Add Task", self._add, bg=ACCENT, fg="white", abg=ACCENT2,
            font=FONT_SM).pack(side=tk.RIGHT, padx=12)
        separator(self)

        # Columns
        col_container = tk.Frame(self, bg=BG)
        col_container.pack(fill=tk.BOTH, expand=True, padx=12, pady=12)
        col_container.columnconfigure(0,weight=1)
        col_container.columnconfigure(1,weight=1)
        col_container.columnconfigure(2,weight=1)

        for c, (status, label, color) in enumerate(COLUMNS):
            frame = tk.Frame(col_container, bg=BG)
            frame.grid(row=0, column=c, sticky="nsew", padx=5)

            col_hdr = tk.Frame(frame, bg=hex_mix(color,BG,0.15),
                               pady=7, padx=10, relief=tk.FLAT)
            col_hdr.pack(fill=tk.X)
            dot = tk.Label(col_hdr, text="●", bg=hex_mix(color,BG,0.15),
                           fg=color, font=("Segoe UI",9))
            dot.pack(side=tk.LEFT)
            tk.Label(col_hdr, text=f"  {label}", bg=hex_mix(color,BG,0.15),
                     fg=color, font=("Segoe UI",10,"bold")).pack(side=tk.LEFT)
            cnt = tk.Label(col_hdr, text="0", bg=hex_mix(color,BG,0.2),
                           fg=color, font=("Segoe UI",9,"bold"), padx=7, pady=1)
            cnt.pack(side=tk.RIGHT)
            self._count_lbls[status] = cnt

            # Scrollable cards area
            scroll_frame = tk.Frame(frame, bg=BG)
            scroll_frame.pack(fill=tk.BOTH, expand=True, pady=4)
            vsb = tk.Scrollbar(scroll_frame, bg=PANEL2, troughcolor=BG, width=6, bd=0)
            vsb.pack(side=tk.RIGHT, fill=tk.Y)
            canvas = tk.Canvas(scroll_frame, bg=BG, bd=0, highlightthickness=0,
                                yscrollcommand=vsb.set)
            canvas.pack(fill=tk.BOTH, expand=True)
            vsb.config(command=canvas.yview)
            cards = tk.Frame(canvas, bg=BG)
            win = canvas.create_window((0,0), window=cards, anchor=tk.NW)
            cards.bind("<Configure>", lambda e, cv=canvas: cv.configure(scrollregion=cv.bbox("all")))
            canvas.bind("<Configure>", lambda e, cv=canvas, w=win: cv.itemconfig(w, width=e.width))
            bind_mousewheel(canvas, canvas.yview)
            self._col_frames[status] = cards

    def refresh(self):
        proj = self._get_proj()
        for status, cards in self._col_frames.items():
            for w in cards.winfo_children(): w.destroy()
        for status in self._count_lbls:
            self._count_lbls[status].config(text="0")
        if not proj: return
        tasks = self._tm.for_project(proj.pid)
        for status, cards in self._col_frames.items():
            col_tasks = [t for t in tasks if t.status==status]
            self._count_lbls[status].config(text=str(len(col_tasks)))
            for t in col_tasks:
                self._render_card(cards, t)

    def _render_card(self, container, task):
        card = tk.Frame(container, bg=PANEL2, bd=0, relief=tk.FLAT)
        card.pack(fill=tk.X, padx=2, pady=3, ipadx=6, ipady=6)

        top = tk.Frame(card, bg=PANEL2)
        top.pack(fill=tk.X, padx=8, pady=(6,2))
        tk.Label(top, text="●", bg=PANEL2, fg=pri_color(task.priority),
                 font=("Segoe UI",9)).pack(side=tk.LEFT)
        tk.Label(top, text=task.title, bg=PANEL2, fg=TEXT,
                 font=("Segoe UI",9,"bold"), wraplength=140,
                 anchor=tk.W, justify=tk.LEFT).pack(side=tk.LEFT, padx=4, fill=tk.X, expand=True)

        if task.desc:
            tk.Label(card, text=task.desc, bg=PANEL2, fg=DIM,
                     font=FONT_XS, wraplength=150, anchor=tk.W,
                     justify=tk.LEFT).pack(fill=tk.X, padx=20, pady=(0,4))

        bottom = tk.Frame(card, bg=PANEL2)
        bottom.pack(fill=tk.X, padx=8, pady=(0,4))

        # Assignee avatar
        m = member_by_id(task.assignee)
        if m:
            av = avatar_canvas(bottom, m["avatar"], m["color"], size=18, bg=PANEL2)
            av.pack(side=tk.LEFT)
            tk.Label(bottom, text=m["name"].split()[0], bg=PANEL2, fg=DIM,
                     font=FONT_XS).pack(side=tk.LEFT, padx=3)

        # Priority tag
        pc = pri_color(task.priority)
        tk.Label(bottom, text=task.priority, bg=hex_mix(pc,PANEL2,0.15),
                 fg=pc, font=("Segoe UI",7,"bold"), padx=5, pady=1).pack(side=tk.LEFT, padx=4)

        # Action buttons
        ORDER = [TODO, IN_PROG, DONE]
        idx = ORDER.index(task.status)
        bf = tk.Frame(card, bg=PANEL2)
        bf.pack(fill=tk.X, padx=8, pady=(2,4))

        if idx > 0:
            btn(bf,"← Back", lambda s=ORDER[idx-1],t=task: self._move(t,s),
                bg=BORDER, fg=WARN, abg=hex_mix(WARN,BORDER,0.2), afg=WARN,
                font=FONT_XS, px=6, py=2).pack(side=tk.LEFT)
        if idx < 2:
            btn(bf,"Forward →", lambda s=ORDER[idx+1],t=task: self._move(t,s),
                bg=BORDER, fg=SUCCESS, abg=hex_mix(SUCCESS,BORDER,0.2), afg=SUCCESS,
                font=FONT_XS, px=6, py=2).pack(side=tk.LEFT, padx=(4,0))
        btn(bf,"✕", lambda t=task: self._delete(t),
            bg=PANEL2, fg=DIM, abg=hex_mix(ERROR,PANEL2,0.2), afg=ERROR,
            font=FONT_XS, px=4, py=2).pack(side=tk.RIGHT)

    def _move(self, task, status):
        self._tm.move(task.tid, status); self.refresh()

    def _delete(self, task):
        if messagebox.askyesno("Delete", f"Delete '{task.title}'?"):
            self._tm.delete(task.tid); self.refresh()

    def _add(self):
        proj = self._get_proj()
        if not proj: messagebox.showinfo("No Project","Select a project first."); return
        dlg = _TaskDialog(self)
        if dlg.result:
            title, desc, priority, assignee = dlg.result
            self._tm.add(proj.pid, title, desc, priority, assignee)
            self.refresh()

class _TaskDialog(tk.simpledialog.Dialog):
    def __init__(self, parent):
        self.result = None
        super().__init__(parent, title="New Task")

    def body(self, master):
        master.config(bg=PANEL2)
        def row(r, lbl):
            tk.Label(master, text=lbl, bg=PANEL2, fg=DIM, font=FONT_SM).grid(
                row=r, column=0, sticky=tk.W, pady=5, padx=8)
        row(0,"Title:"); row(1,"Description:"); row(2,"Priority:"); row(3,"Assign To:")

        self._title = tk.Entry(master, bg=PANEL, fg=TEXT, insertbackground=TEXT,
                                relief=tk.FLAT, bd=4, font=FONT_SM, width=30)
        self._title.grid(row=0, column=1, pady=5, padx=8)

        self._desc = tk.Entry(master, bg=PANEL, fg=TEXT, insertbackground=TEXT,
                               relief=tk.FLAT, bd=4, font=FONT_SM, width=30)
        self._desc.grid(row=1, column=1, pady=5, padx=8)

        self._priority = tk.StringVar(value="medium")
        pf = tk.Frame(master, bg=PANEL2); pf.grid(row=2, column=1, sticky=tk.W, pady=5, padx=8)
        for val,lbl,color in [("low","Low",DIM),("medium","Medium",WARN),("high","High",ERROR)]:
            tk.Radiobutton(pf, text=lbl, variable=self._priority, value=val,
                           bg=PANEL2, fg=TEXT, selectcolor=PANEL, activebackground=PANEL2,
                           font=FONT_SM).pack(side=tk.LEFT, padx=6)

        members = get_members()
        default_assignee = members[0]["id"] if members else ""
        self._assignee = tk.StringVar(value=default_assignee)
        af = tk.Frame(master, bg=PANEL2); af.grid(row=3, column=1, sticky=tk.W, pady=5, padx=8)
        if not members:
            tk.Label(af, text="No teammates yet", bg=PANEL2, fg=ERROR, font=FONT_SM).pack(anchor=tk.W)
        for m in members:
            tk.Radiobutton(af, text=m["name"].split()[0], variable=self._assignee,
                           value=m["id"], bg=PANEL2, fg=TEXT, selectcolor=PANEL,
                           activebackground=PANEL2, font=FONT_SM).pack(side=tk.LEFT, padx=4)
        self.configure(bg=PANEL2)
        return self._title

    def apply(self):
        title = self._title.get().strip()
        if not get_members():
            messagebox.showerror("No team", "Create teammates first in Settings / Team before adding tasks")
            self.result = None
            return
        if title:
            self.result = (title, self._desc.get().strip(),
                           self._priority.get(), self._assignee.get())

    def buttonbox(self):
        box = tk.Frame(self, bg=PANEL2, pady=8); box.pack()
        btn(box,"Add Task",self.ok, bg=ACCENT,fg="white",abg=ACCENT2).pack(side=tk.LEFT,padx=6)
        btn(box,"Cancel",self.cancel,bg=PANEL,fg=TEXT,abg=BORDER).pack(side=tk.LEFT,padx=6)
        self.configure(bg=PANEL2)

import tkinter.simpledialog
