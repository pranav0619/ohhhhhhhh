import tkinter as tk
from tkinter import simpledialog

from ui.theme import PANEL2, PANEL, TEXT, DIM, FONT, FONT_SM, ACCENT, ACCENT2, BORDER, btn


class FancyInputDialog(simpledialog.Dialog):
    def __init__(self, parent, title, prompt, initialvalue="", password=False):
        self._prompt = prompt
        self._initial = initialvalue or ""
        self._password = password
        self.value = None
        super().__init__(parent, title=title)

    def body(self, master):
        master.configure(bg=PANEL2, padx=18, pady=14)
        tk.Label(
            master, text=self._prompt, bg=PANEL2, fg=TEXT, font=("Segoe UI", 11, "bold")
        ).pack(anchor=tk.W, pady=(0, 10))
        self._entry = tk.Entry(
            master,
            bg=PANEL,
            fg=TEXT,
            insertbackground=TEXT,
            relief=tk.FLAT,
            bd=6,
            font=FONT,
            width=36,
            show="*" if self._password else "",
        )
        self._entry.pack(fill=tk.X)
        self._entry.insert(0, self._initial)
        return self._entry

    def validate(self):
        value = self._entry.get().strip()
        if not value:
            return False
        self.value = value
        return True

    def buttonbox(self):
        box = tk.Frame(self, bg=PANEL2, pady=10)
        box.pack(fill=tk.X)
        btn(box, "OK", self.ok, bg=ACCENT, fg="white", abg=ACCENT2).pack(side=tk.LEFT, padx=(18, 6))
        btn(box, "Cancel", self.cancel, bg=PANEL, fg=DIM, abg=BORDER).pack(side=tk.LEFT)
        self.bind("<Return>", self.ok)
        self.bind("<Escape>", self.cancel)


def ask_text(parent, title, prompt, initialvalue="", password=False):
    dlg = FancyInputDialog(parent, title=title, prompt=prompt, initialvalue=initialvalue, password=password)
    return dlg.value
