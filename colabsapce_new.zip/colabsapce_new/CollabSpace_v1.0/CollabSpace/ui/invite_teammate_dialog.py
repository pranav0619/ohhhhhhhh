import tkinter as tk
from tkinter import simpledialog
from ui.theme import PANEL2, PANEL, TEXT, DIM, FONT_SM, ACCENT, ACCENT2, BORDER, btn


class InviteTeammateDialog(simpledialog.Dialog):
    def __init__(self, parent, projects):
        self.result = None
        self._projects = projects
        super().__init__(parent, title="Invite teammate")

    def body(self, master):
        master.configure(bg=PANEL2, padx=14, pady=12)
        tk.Label(master, text="Project", bg=PANEL2, fg=DIM, font=FONT_SM).grid(row=0, column=0, sticky=tk.W, pady=4)
        self._project = tk.StringVar(value=self._projects[0].pid if self._projects else "")
        opts = [f"{p.pid}:{p.name}" for p in self._projects] or [""]
        tk.OptionMenu(master, self._project, *opts).grid(row=0, column=1, sticky=tk.EW, pady=4)

        tk.Label(master, text="Permission", bg=PANEL2, fg=DIM, font=FONT_SM).grid(row=1, column=0, sticky=tk.W, pady=4)
        self._perm = tk.StringVar(value="viewer")
        tk.OptionMenu(master, self._perm, "viewer", "editor", "admin").grid(row=1, column=1, sticky=tk.EW, pady=4)

        tk.Label(master, text="Expiry", bg=PANEL2, fg=DIM, font=FONT_SM).grid(row=2, column=0, sticky=tk.W, pady=4)
        self._exp = tk.StringVar(value="session")
        tk.OptionMenu(master, self._exp, "session", "24h", "permanent").grid(row=2, column=1, sticky=tk.EW, pady=4)
        return None

    def apply(self):
        proj_value = self._project.get()
        pid = proj_value.split(":", 1)[0] if proj_value else ""
        self.result = (pid, self._perm.get(), self._exp.get())

    def buttonbox(self):
        box = tk.Frame(self, bg=PANEL2, pady=8)
        box.pack(fill=tk.X)
        btn(box, "Send Invite", self.ok, bg=ACCENT, fg="white", abg=ACCENT2).pack(side=tk.LEFT, padx=(14, 6))
        btn(box, "Cancel", self.cancel, bg=PANEL, fg=TEXT, abg=BORDER).pack(side=tk.LEFT)
