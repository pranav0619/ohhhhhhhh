"""ui/notes_panel.py — project notes panel."""
import tkinter as tk
from tkinter import messagebox
from ui.theme import *
from ui.dialogs import ask_text

class NotesPanel(tk.Frame):
    def __init__(self, parent, note_manager, get_project):
        super().__init__(parent, bg=BG)
        self._nm = note_manager
        self._get_proj = get_project
        self._active_nid = None
        self._note_ids = []
        self._build()

    def _build(self):
        # Header
        hdr = tk.Frame(self, bg=PANEL, pady=10)
        hdr.pack(fill=tk.X)
        tk.Label(hdr, text="  Notes", bg=PANEL, fg=TEXT,
                 font=("Segoe UI",13,"bold")).pack(side=tk.LEFT, padx=8)
        btn(hdr,"+ New Note",self._new, bg=ACCENT,fg="white",abg=ACCENT2,
            font=FONT_SM).pack(side=tk.RIGHT, padx=12)
        separator(self)

        # Horizontal split: list | editor
        pane = tk.PanedWindow(self, orient=tk.HORIZONTAL, bg=BORDER,
                              sashwidth=4, sashrelief=tk.FLAT)
        pane.pack(fill=tk.BOTH, expand=True)

        # ── Note list ─────────────────────────────────────────────────────
        list_frame = tk.Frame(pane, bg=PANEL)
        vsb = tk.Scrollbar(list_frame, bg=PANEL2, troughcolor=PANEL, width=6, bd=0)
        vsb.pack(side=tk.RIGHT, fill=tk.Y)
        self._listbox = tk.Listbox(list_frame, bg=PANEL, fg=TEXT, font=FONT_SM,
                                    selectbackground=ACCENT, selectforeground="white",
                                    activestyle="none", bd=0, highlightthickness=0,
                                    yscrollcommand=vsb.set, cursor="hand2")
        self._listbox.pack(fill=tk.BOTH, expand=True)
        vsb.config(command=self._listbox.yview)
        bind_mousewheel(self._listbox, self._listbox.yview)
        self._listbox.bind("<<ListboxSelect>>", self._on_select)
        pane.add(list_frame, minsize=180, width=220)

        # ── Note editor ───────────────────────────────────────────────────
        edit_frame = tk.Frame(pane, bg=PANEL2)

        et = tk.Frame(edit_frame, bg=PANEL2, pady=6)
        et.pack(fill=tk.X, padx=8)
        self._title_var = tk.StringVar()
        self._title_entry = tk.Entry(edit_frame, textvariable=self._title_var,
                                      bg=PANEL, fg=TEXT, insertbackground=TEXT,
                                      relief=tk.FLAT, bd=6, font=("Segoe UI",12,"bold"),
                                      state=tk.DISABLED)
        self._title_entry.pack(fill=tk.X, padx=8, pady=6)

        # Editor toolbar
        et2 = tk.Frame(edit_frame, bg=PANEL2, pady=2)
        et2.pack(fill=tk.X, padx=8)
        self._save_btn = btn(et2,"Save",self._save, bg=ACCENT,fg="white",abg=ACCENT2,
                             font=FONT_SM, state=tk.DISABLED)
        self._save_btn.pack(side=tk.LEFT)
        btn(et2,"Delete",self._delete, bg=hex_mix(ERROR,PANEL2,0.15),
            fg=ERROR, abg=hex_mix(ERROR,PANEL2,0.3), afg=ERROR,
            font=FONT_SM).pack(side=tk.LEFT, padx=6)

        # Body text
        bf = tk.Frame(edit_frame, bg=PANEL2)
        bf.pack(fill=tk.BOTH, expand=True, padx=8, pady=6)
        bvsb = tk.Scrollbar(bf, bg=PANEL2, troughcolor=PANEL2, width=6, bd=0)
        bvsb.pack(side=tk.RIGHT, fill=tk.Y)
        self._body = tk.Text(bf, bg="#111116", fg=TEXT, insertbackground=TEXT,
                              font=FONT_MONO, bd=0, relief=tk.FLAT,
                              wrap=tk.WORD, padx=10, pady=8,
                              state=tk.DISABLED, yscrollcommand=bvsb.set)
        self._body.pack(fill=tk.BOTH, expand=True)
        bvsb.config(command=self._body.yview)
        bind_mousewheel(self._body, self._body.yview)
        pane.add(edit_frame, minsize=300)

    def refresh(self):
        proj = self._get_proj()
        self._listbox.delete(0, tk.END)
        self._note_ids = []
        self._clear_editor()
        if not proj: return
        for n in self._nm.for_project(proj.pid):
            display = n.title[:30] + ("…" if len(n.title)>30 else "")
            self._listbox.insert(tk.END, f"  {display}")
            self._note_ids.append(n.nid)

    def _on_select(self, _=None):
        sel = self._listbox.curselection()
        if not sel: return
        nid = self._note_ids[sel[0]]
        n = self._nm.get(nid)
        if n: self._load(n)

    def _load(self, note):
        self._active_nid = note.nid
        self._title_var.set(note.title)
        self._title_entry.config(state=tk.NORMAL)
        self._save_btn.config(state=tk.NORMAL)
        self._body.config(state=tk.NORMAL)
        self._body.delete("1.0", tk.END)
        self._body.insert("1.0", note.body)

    def _save(self):
        if not self._active_nid: return
        title = self._title_var.get().strip()
        body  = self._body.get("1.0", tk.END).rstrip("\n")
        self._nm.update(self._active_nid, title=title, body=body)
        self.refresh()
        if self._active_nid in self._note_ids:
            idx = self._note_ids.index(self._active_nid)
            self._listbox.selection_set(idx)
            n = self._nm.get(self._active_nid)
            if n: self._load(n)

    def _delete(self):
        if not self._active_nid: return
        n = self._nm.get(self._active_nid)
        if not n: return
        if not messagebox.askyesno("Delete Note", f"Delete '{n.title}'?"): return
        self._nm.delete(self._active_nid)
        self._active_nid = None
        self.refresh()

    def _new(self):
        proj = self._get_proj()
        if not proj: messagebox.showinfo("No Project","Select a project first."); return
        title = ask_text(self, "New Note", "Enter note title:")
        if not title: return
        n = self._nm.create(proj.pid, title.strip())
        self.refresh()
        if n.nid in self._note_ids:
            idx = self._note_ids.index(n.nid)
            self._listbox.selection_set(idx)
            self._load(n)

    def _clear_editor(self):
        self._active_nid = None
        self._title_var.set("")
        self._title_entry.config(state=tk.DISABLED)
        self._save_btn.config(state=tk.DISABLED)
        self._body.config(state=tk.NORMAL)
        self._body.delete("1.0", tk.END)
        self._body.config(state=tk.DISABLED)
