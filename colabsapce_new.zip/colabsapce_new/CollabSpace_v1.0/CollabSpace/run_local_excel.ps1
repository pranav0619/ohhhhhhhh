# CollabSpace — save users, projects, tasks, notes to one Excel file (.xlsx)
# 1) pip install openpyxl
# 2) Run this script (or set the same env vars in CMD).

# Creates/updates collabspace_data.xlsx in this folder (same folder as main.py).
$env:COLLABSPACE_USE_EXCEL = "1"

# Or set a custom file elsewhere (uncomment and edit):
# $env:COLLABSPACE_EXCEL_PATH = "C:\path\to\collabspace_data.xlsx"

# One-time: import existing %USERPROFILE%\.collabspace\*.json into the workbook, then remove:
# $env:COLLABSPACE_MIGRATE_JSON_TO_EXCEL = "1"

Set-Location $PSScriptRoot
python main.py
