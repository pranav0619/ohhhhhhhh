$ErrorActionPreference = "Stop"

$appDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$pythonExe = (Get-Command python).Source
$mainPy = Join-Path $appDir "main.py"
$desktop = [Environment]::GetFolderPath("Desktop")
$shortcutPath = Join-Path $desktop "CollabSpace.lnk"

$ws = New-Object -ComObject WScript.Shell
$shortcut = $ws.CreateShortcut($shortcutPath)
$shortcut.TargetPath = $pythonExe
$shortcut.Arguments = "`"$mainPy`""
$shortcut.WorkingDirectory = $appDir
$shortcut.IconLocation = "$pythonExe,0"
$shortcut.WindowStyle = 1
$shortcut.Description = "Launch CollabSpace"
$shortcut.Save()

Write-Host "Desktop shortcut created at: $shortcutPath"
