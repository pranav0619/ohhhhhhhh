"""data/excel_storage.py — store each namespace as a worksheet in one .xlsx file."""

from __future__ import annotations

import json
import os
import re
from typing import Any


def _sheet_name(ns: str) -> str:
    s = re.sub(r"[\[\]:*?/\\]", "_", ns)[:31].strip() or "data"
    return s


def _encode_val(v: Any) -> Any:
    if v is None:
        return ""
    if isinstance(v, (dict, list)):
        return json.dumps(v, ensure_ascii=False)
    return v


def _decode_val(cell: Any) -> Any:
    if cell is None or cell == "":
        return None
    if isinstance(cell, str):
        t = cell.strip()
        if t.startswith("{") or t.startswith("["):
            try:
                return json.loads(t)
            except json.JSONDecodeError:
                pass
        return cell
    return cell


class ExcelStorage:
    def __init__(self, path: str):
        self._path = os.path.abspath(path)
        d = os.path.dirname(self._path)
        if d:
            os.makedirs(d, exist_ok=True)

    def _load_wb(self):
        try:
            from openpyxl import load_workbook  # type: ignore
        except Exception as e:
            raise RuntimeError(
                "Excel storage needs `openpyxl`. Install with: pip install openpyxl\n"
                f"Original error: {e}"
            )
        if os.path.isfile(self._path):
            return load_workbook(self._path)
        from openpyxl import Workbook  # type: ignore

        return Workbook()

    def _save_wb(self, wb) -> None:
        wb.save(self._path)

    def load(self, ns: str) -> list:
        if not os.path.isfile(self._path):
            return []
        wb = self._load_wb()
        name = _sheet_name(ns)
        if name not in wb.sheetnames:
            return []
        ws = wb[name]
        rows = list(ws.iter_rows(values_only=True))
        if not rows:
            return []
        headers = [str(h) if h is not None else "" for h in rows[0]]
        if not any(headers):
            return []
        out = []
        for row in rows[1:]:
            d = {}
            for i, h in enumerate(headers):
                if not h:
                    continue
                val = row[i] if i < len(row) else None
                d[h] = _decode_val(val)
            # skip completely empty rows
            if any(v is not None and v != "" for v in d.values()):
                out.append(d)
        return out

    def save_all(self, ns: str, records: list) -> None:
        wb = self._load_wb()
        name = _sheet_name(ns)
        if name in wb.sheetnames:
            wb.remove(wb[name])
        ws = wb.create_sheet(name)

        if not records:
            if "Sheet" in wb.sheetnames and len(wb.sheetnames) > 1:
                wb.remove(wb["Sheet"])
            self._save_wb(wb)
            return

        all_keys: list[str] = []
        seen = set()
        for r in records:
            for k in r:
                if k not in seen:
                    seen.add(k)
                    all_keys.append(k)

        ws.append(all_keys)
        for r in records:
            row = [_encode_val(r.get(k)) for k in all_keys]
            ws.append(row)

        # Drop default empty "Sheet" if other sheets exist
        if "Sheet" in wb.sheetnames and len(wb.sheetnames) > 1:
            wb.remove(wb["Sheet"])

        self._save_wb(wb)

    def flush(self) -> bool:
        return True
