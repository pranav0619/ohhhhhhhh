"""data/postgres_storage.py — PostgreSQL-backed Storage adapter.

This keeps the existing Storage API (`load/save_all/flush`) so the rest of the app
does not need to change.
"""

from __future__ import annotations

import os
import json
from typing import Any


class PostgresStorage:
    def __init__(self, dsn: str):
        self._dsn = dsn
        self._conn = None
        self._ensure_schema()

    def _connect(self):
        if self._conn is not None:
            return self._conn
        try:
            # psycopg v3
            import psycopg  # type: ignore
        except Exception as e:
            raise RuntimeError(
                "PostgreSQL storage needs the `psycopg` package. "
                "Install with: pip install psycopg[binary]\n"
                f"Original error: {e}"
            )
        self._conn = psycopg.connect(self._dsn)
        return self._conn

    def _ensure_schema(self):
        conn = self._connect()
        with conn.cursor() as cur:
            cur.execute(
                """
                CREATE TABLE IF NOT EXISTS collabspace_data (
                    ns text PRIMARY KEY,
                    records jsonb NOT NULL
                );
                """
            )
        conn.commit()

    def load(self, ns: str) -> list:
        conn = self._connect()
        with conn.cursor() as cur:
            cur.execute(
                "SELECT records FROM collabspace_data WHERE ns = %s;",
                (ns,),
            )
            row = cur.fetchone()
            if not row:
                return []
            records = row[0]
            # psycopg returns jsonb as Python objects by default in many cases;
            # if it's still a string, parse it.
            if isinstance(records, str):
                try:
                    records = json.loads(records)
                except Exception:
                    return []
            return list(records) if isinstance(records, list) else []

    def save_all(self, ns: str, records: list):
        conn = self._connect()
        # Store the entire list for compatibility with current managers.
        payload = records
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO collabspace_data (ns, records)
                VALUES (%s, %s::jsonb)
                ON CONFLICT (ns) DO UPDATE SET records = EXCLUDED.records;
                """,
                (ns, json.dumps(payload, ensure_ascii=False)),
            )
        conn.commit()

    def flush(self):
        # We commit on every write, so this is a no-op.
        return True

