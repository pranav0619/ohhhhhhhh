"""data/remote_storage.py — basic shared DB API client/server for CollabSpace."""
import os, json, urllib.request, urllib.error
from urllib.parse import urljoin

class RemoteStorageClient:
    def __init__(self, server_url):
        self.server_url = server_url.rstrip('/') + '/' if server_url else None

    def _url(self, path):
        if not self.server_url:
            raise RuntimeError("Remote server URL is not configured")
        return urljoin(self.server_url, path)

    def load(self, ns):
        try:
            u = self._url(f"load/{ns}")
            with urllib.request.urlopen(u, timeout=5) as r:
                return json.loads(r.read().decode('utf-8'))
        except Exception as e:
            print(f"[RemoteStorage] load error: {e}")
            return []

    def save_all(self, ns, records):
        try:
            u = self._url(f"save/{ns}")
            data = json.dumps(records).encode('utf-8')
            req = urllib.request.Request(u, data=data, method='POST', headers={'Content-Type':'application/json'})
            with urllib.request.urlopen(req, timeout=5) as r:
                return json.loads(r.read().decode('utf-8'))
        except Exception as e:
            print(f"[RemoteStorage] save_all error: {e}")
            return None

    def flush(self):
        # no-op for remote
        return True

# Very simple local-only server (no external dependencies)
from http.server import HTTPServer, BaseHTTPRequestHandler

class RemoteStorageHandler(BaseHTTPRequestHandler):
    DATABASE_DIR = os.path.expanduser('~/.collabspace/remote_db')
    os.makedirs(DATABASE_DIR, exist_ok=True)

    def _load(self, ns):
        path = os.path.join(self.DATABASE_DIR, f"{ns}.json")
        if not os.path.exists(path):
            return []
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)

    def _save(self, ns, data):
        path = os.path.join(self.DATABASE_DIR, f"{ns}.json")
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        return True

    def _respond(self, code, obj):
        self.send_response(code)
        self.send_header('Content-Type', 'application/json')
        self.end_headers()
        self.wfile.write(json.dumps(obj).encode('utf-8'))

    def do_GET(self):
        if self.path.startswith('/load/'):
            ns = self.path.split('/load/')[-1]
            if ns:
                data = self._load(ns)
                self._respond(200, data)
                return
        self._respond(404, {'error': 'not found'})

    def do_POST(self):
        if self.path.startswith('/save/'):
            ns = self.path.split('/save/')[-1]
            length = int(self.headers.get('Content-Length', 0))
            body = self.rfile.read(length).decode('utf-8')
            try:
                payload = json.loads(body)
                self._save(ns, payload)
                self._respond(200, {'ok': True})
                return
            except Exception as e:
                self._respond(400, {'error': str(e)})
                return
        self._respond(404, {'error': 'not found'})

def run_remote_server(host='0.0.0.0', port=8080):
    print(f"[RemoteStorage] Starting server http://{host}:{port}")
    HTTPServer((host, port), RemoteStorageHandler).serve_forever()

# Optional WebSocket-based peer-to-peer sync for LAN
try:
    import asyncio
    import threading
    import websockets
except ImportError:
    websockets = None

class PeerSync:
    def __init__(self, host='0.0.0.0', port=8765):
        if websockets is None:
            raise RuntimeError('websockets package not installed')
        self.host = host
        self.port = port
        self._clients = set()
        self._loop = None

    async def _handler(self, websocket, path):
        self._clients.add(websocket)
        try:
            async for message in websocket:
                for c in list(self._clients):
                    if c != websocket:
                        await c.send(message)
        finally:
            self._clients.remove(websocket)

    def start(self):
        if websockets is None:
            raise RuntimeError('websockets package not installed. Install via pip install websockets')

        async def _serve():
            async with websockets.serve(self._handler, self.host, self.port):
                await asyncio.Future()

        self._loop = asyncio.new_event_loop()
        t = threading.Thread(target=self._loop.run_until_complete, args=(_serve(),), daemon=True)
        t.start()
        print(f"[PeerSync] WebSocket peer sync running on ws://{self.host}:{self.port}")

    async def connect_and_forward(self, uri, message):
        if websockets is None:
            raise RuntimeError('websockets package not installed')
        async with websockets.connect(uri) as ws:
            await ws.send(message)

    def broadcast(self, uri, message):
        if websockets is None:
            raise RuntimeError('websockets package not installed')
        async def _wrap():
            await self.connect_and_forward(uri, message)
        if self._loop:
            asyncio.run_coroutine_threadsafe(_wrap(), self._loop)

