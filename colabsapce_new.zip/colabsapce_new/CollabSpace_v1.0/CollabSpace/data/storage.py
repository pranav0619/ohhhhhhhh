"""data/storage.py — storage adapter.

Default is local JSON files.
If `COLLABSPACE_EXCEL_PATH` is set (or `COLLABSPACE_USE_EXCEL=1`), one .xlsx file is used
(by default `collabspace_data.xlsx` next to `main.py`).
If `COLLABSPACE_DB_DSN` is set, storage uses PostgreSQL instead (ignored when Excel is active).
"""

import json
import os

from data.remote_storage import RemoteStorageClient
from data.postgres_storage import PostgresStorage
from data.excel_storage import ExcelStorage

_DIR = os.path.join(os.path.expanduser("~"), ".collabspace")
# Project root (folder containing main.py) — default Excel file lives here so it shows in the workspace.
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

class Storage:
    def __init__(self, base_dir=_DIR, remote_url=None):
        excel_path = os.environ.get("COLLABSPACE_EXCEL_PATH", "").strip()
        if not excel_path and os.environ.get("COLLABSPACE_USE_EXCEL") == "1":
            excel_path = os.path.join(_PROJECT_ROOT, "collabspace_data.xlsx")
        self._excel = ExcelStorage(excel_path) if excel_path else None

        db_dsn = os.environ.get("COLLABSPACE_DB_DSN") or os.environ.get("COLLABSPACE_POSTGRES_DSN")
        self._postgres = PostgresStorage(db_dsn) if (db_dsn and self._excel is None) else None

        self._base = base_dir
        os.makedirs(self._base, exist_ok=True)
        self._cache = {}
        self._remote = RemoteStorageClient(remote_url) if remote_url else None

        # Optional one-time migration from local JSON files to Postgres.
        # Usage: set COLLABSPACE_MIGRATE_JSON_TO_POSTGRES=1
        if self._postgres is not None and os.environ.get("COLLABSPACE_MIGRATE_JSON_TO_POSTGRES") == "1":
            try:
                for fn in os.listdir(self._base):
                    if not fn.endswith(".json"):
                        continue
                    ns = fn[:-5]
                    p = os.path.join(self._base, fn)
                    with open(p, encoding="utf-8") as f:
                        data = json.load(f)
                    if isinstance(data, list):
                        self._postgres.save_all(ns, data)
            except Exception:
                # If migration fails, app should still work (it will just use empty DB).
                pass

        # Optional one-time migration from local JSON files to Excel workbook.
        if self._excel is not None and os.environ.get("COLLABSPACE_MIGRATE_JSON_TO_EXCEL") == "1":
            try:
                for fn in os.listdir(self._base):
                    if not fn.endswith(".json"):
                        continue
                    ns = fn[:-5]
                    p = os.path.join(self._base, fn)
                    with open(p, encoding="utf-8") as f:
                        data = json.load(f)
                    if isinstance(data, list):
                        self._excel.save_all(ns, data)
            except Exception:
                pass

    def load(self, ns: str) -> list:
        if self._excel is not None:
            return self._excel.load(ns)
        if self._postgres is not None:
            return self._postgres.load(ns)
        if self._remote:
            data = self._remote.load(ns)
            if data is not None:
                self._cache[ns] = data
                return list(data)

        if ns not in self._cache:
            path = self._path(ns)
            if not os.path.exists(path):
                self._cache[ns] = []
            else:
                try:
                    with open(path, encoding="utf-8") as f:
                        d = json.load(f)
                    self._cache[ns] = d if isinstance(d, list) else []
                except Exception:
                    self._cache[ns] = []
        return list(self._cache[ns])

    def save_all(self, ns: str, records: list):
        if self._excel is not None:
            return self._excel.save_all(ns, records)
        if self._postgres is not None:
            return self._postgres.save_all(ns, records)
        self._cache[ns] = list(records)
        try:
            with open(self._path(ns), "w", encoding="utf-8") as f:
                json.dump(records, f, indent=2, ensure_ascii=False)
        except OSError as e:
            print(f"[Storage] warn: {e}")
        if self._remote:
            self._remote.save_all(ns, records)

    def flush(self):
        if self._excel is not None:
            return self._excel.flush()
        if self._postgres is not None:
            return self._postgres.flush()
        for ns, records in self._cache.items():
            try:
                with open(self._path(ns), "w", encoding="utf-8") as f:
                    json.dump(records, f, indent=2, ensure_ascii=False)
            except OSError:
                pass

    def _path(self, ns):
        return os.path.join(self._base, f"{ns}.json")
