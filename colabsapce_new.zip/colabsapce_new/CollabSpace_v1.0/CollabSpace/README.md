# CollabSpace v1.0

A collaborative desktop workspace for students — built with Python + Tkinter.

## Features

| Feature | Status |
|---|---|
| Multi-project workspace | ✅ |
| Multi-tab code editor | ✅ |
| Python syntax highlighting | ✅ |
| Code execution (subprocess) | ✅ |
| Live output console | ✅ |
| Kanban task board (To Do / In Progress / Done) | ✅ |
| Project notes (markdown scratchpad) | ✅ |
| File explorer (create / open / rename / delete) | ✅ |
| Team members & status view | ✅ |
| Activity log | ✅ |
| Find bar (Ctrl+F) | ✅ |
| Font zoom (Ctrl+= / Ctrl+-) | ✅ |
| Dark VS Code-style UI | ✅ |
| Full data persistence (JSON) | ✅ |

## Requirements

- Python 3.10 or newer
- Tkinter (bundled with Python on Windows/macOS; on Linux: `sudo apt install python3-tk`)

## Run

```bash
cd CollabSpace
python main.py
```

## Folder Structure

```
CollabSpace/
├── main.py              ← Entry point — run this
├── README.md
├── data/
│   ├── __init__.py
│   └── storage.py       ← JSON persistence
├── core/
│   ├── __init__.py
│   ├── project_manager.py
│   ├── task_manager.py
│   ├── note_manager.py
│   ├── file_manager.py
│   ├── executor.py      ← subprocess code runner
│   └── members.py       ← team members & activity log
└── ui/
    ├── __init__.py
    ├── theme.py          ← design tokens & shared helpers
    ├── syntax.py         ← Python syntax highlighting
    ├── topbar.py         ← top navigation bar
    ├── nav_rail.py       ← left icon rail
    ├── file_tree.py      ← file explorer panel
    ├── editor_panel.py   ← multi-tab code editor
    ├── task_board.py     ← Kanban board
    ├── notes_panel.py    ← project notes
    ├── team_panel.py     ← team members view
    ├── activity_panel.py ← activity log
    ├── right_panel.py    ← stats sidebar
    └── dashboard.py      ← root container / wiring
```

## Data Storage

All data is saved to `~/.collabspace/`:
- `projects.json` — project list
- `tasks.json` — all tasks
- `notes.json` — all notes
- `projects/<pid>/` — project source files

## Keyboard Shortcuts

| Shortcut | Action |
|---|---|
| Ctrl+S | Save current file |
| Ctrl+F | Toggle find bar |
| Ctrl+= | Zoom in |
| Ctrl+- | Zoom out |
| Tab | Insert 4 spaces |
| Ctrl+Z | Undo |
| Ctrl+Y | Redo |
| Enter (find bar) | Next match |
| Shift+Enter (find bar) | Previous match |
| Escape (find bar) | Close find bar |
