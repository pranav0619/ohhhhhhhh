# CollabSpace — run with local PostgreSQL
# 1) Install deps:  pip install -r requirements.txt
# 2) Create a database (e.g. in pgAdmin or: psql -U postgres -c "CREATE DATABASE collabspace;")
# 3) Edit COLLABSPACE_DB_DSN below (user, password, host, port, database name).

# Example: postgresql://USER:PASSWORD@localhost:5432/collabspace
$env:COLLABSPACE_DB_DSN = "postgresql://postgres:YOUR_PASSWORD@localhost:5432/collabspace"

# One-time: copy existing JSON from %USERPROFILE%\.collabspace into Postgres, then remove this line.
# $env:COLLABSPACE_MIGRATE_JSON_TO_POSTGRES = "1"

Set-Location $PSScriptRoot
python main.py
