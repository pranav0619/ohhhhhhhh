"""core/task_manager.py"""
import uuid
from datetime import datetime
from data.storage import Storage

NS = "tasks"
TODO = "todo"; IN_PROG = "in_progress"; DONE = "done"
ALL_STATUS = [TODO, IN_PROG, DONE]

class Task:
    def __init__(self, tid, project_id, title, desc, status, priority, assignee, created):
        self.tid=tid; self.project_id=project_id; self.title=title
        self.desc=desc; self.status=status; self.priority=priority
        self.assignee=assignee; self.created=created

    def to_dict(self):
        return dict(tid=self.tid,project_id=self.project_id,title=self.title,
                    desc=self.desc,status=self.status,priority=self.priority,
                    assignee=self.assignee,created=self.created)

    @classmethod
    def from_dict(cls,d):
        return cls(d.get("tid",str(uuid.uuid4())),d.get("project_id",""),
                   d.get("title",""),d.get("desc",""),d.get("status",TODO),
                   d.get("priority","medium"),d.get("assignee",""),d.get("created",""))

class TaskManager:
    def __init__(self, storage: Storage):
        self._s = storage
        self._tasks: list[Task] = [Task.from_dict(r) for r in self._s.load(NS)]
        self._change_listener = None

    def set_change_listener(self, cb):
        self._change_listener = cb

    def add(self, project_id, title, desc="", priority="medium", assignee="") -> Task:
        t = Task(str(uuid.uuid4()), project_id, title.strip(), desc.strip(),
                 TODO, priority, assignee, datetime.now().strftime("%Y-%m-%d"))
        self._tasks.append(t); self._save()
        self._emit("task_create", t.to_dict())
        return t

    def for_project(self, pid) -> list[Task]:
        return [t for t in self._tasks if t.project_id==pid]

    def move(self, tid, status) -> bool:
        t = self._get(tid)
        if t and status in ALL_STATUS:
            t.status=status
            self._save()
            self._emit("task_update", t.to_dict())
            return True
        return False

    def delete(self, tid) -> bool:
        before = len(self._tasks)
        self._tasks = [t for t in self._tasks if t.tid!=tid]
        if len(self._tasks)<before:
            self._save()
            self._emit("task_delete", {"tid": tid})
            return True
        return False

    def delete_for_project(self, pid):
        self._tasks = [t for t in self._tasks if t.project_id!=pid]; self._save()

    def _get(self, tid):
        return next((t for t in self._tasks if t.tid==tid), None)

    def _save(self):
        self._s.save_all(NS, [t.to_dict() for t in self._tasks])

    def apply_remote(self, event_type: str, payload: dict):
        if event_type == "task_create":
            if self._get(payload.get("tid", "")):
                return
            self._tasks.append(Task.from_dict(payload))
            self._save()
            return
        if event_type == "task_update":
            t = self._get(payload.get("tid", ""))
            if t:
                t.title = payload.get("title", t.title)
                t.desc = payload.get("desc", t.desc)
                t.status = payload.get("status", t.status)
                t.priority = payload.get("priority", t.priority)
                t.assignee = payload.get("assignee", t.assignee)
            else:
                self._tasks.append(Task.from_dict(payload))
            self._save()
            return
        if event_type == "task_delete":
            self._tasks = [t for t in self._tasks if t.tid != payload.get("tid")]
            self._save()

    def _emit(self, event_type: str, payload: dict):
        if self._change_listener:
            self._change_listener(event_type, payload)
