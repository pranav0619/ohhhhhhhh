# core layer
