"""core/note_manager.py"""
import uuid
from datetime import datetime
from data.storage import Storage

NS = "notes"

class Note:
    def __init__(self, nid, project_id, title, body, updated):
        self.nid=nid; self.project_id=project_id
        self.title=title; self.body=body; self.updated=updated

    def to_dict(self):
        return dict(nid=self.nid,project_id=self.project_id,
                    title=self.title,body=self.body,updated=self.updated)

    @classmethod
    def from_dict(cls,d):
        return cls(d.get("nid",str(uuid.uuid4())),d.get("project_id",""),
                   d.get("title",""),d.get("body",""),d.get("updated",""))

class NoteManager:
    def __init__(self, storage: Storage):
        self._s = storage
        self._notes: list[Note] = [Note.from_dict(r) for r in self._s.load(NS)]
        self._change_listener = None

    def set_change_listener(self, cb):
        self._change_listener = cb

    def create(self, project_id, title, body="") -> Note:
        n = Note(str(uuid.uuid4()), project_id, title.strip() or "Untitled",
                 body, datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        self._notes.insert(0, n); self._save()
        self._emit("note_create", n.to_dict())
        return n

    def for_project(self, pid) -> list[Note]:
        return [n for n in self._notes if n.project_id==pid]

    def get(self, nid) -> Note | None:
        return next((n for n in self._notes if n.nid==nid), None)

    def update(self, nid, title=None, body=None) -> bool:
        n = self.get(nid)
        if not n: return False
        if title is not None: n.title = title.strip() or "Untitled"
        if body  is not None: n.body  = body
        n.updated = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self._save()
        self._emit("note_update", n.to_dict())
        return True

    def delete(self, nid) -> bool:
        before = len(self._notes)
        self._notes = [n for n in self._notes if n.nid!=nid]
        if len(self._notes)<before:
            self._save()
            self._emit("note_delete", {"nid": nid})
            return True
        return False

    def delete_for_project(self, pid):
        self._notes = [n for n in self._notes if n.project_id!=pid]; self._save()

    def _save(self):
        self._s.save_all(NS,[n.to_dict() for n in self._notes])

    def apply_remote(self, event_type: str, payload: dict):
        if event_type == "note_create":
            if self.get(payload.get("nid", "")):
                return
            self._notes.insert(0, Note.from_dict(payload))
            self._save()
            return
        if event_type == "note_update":
            n = self.get(payload.get("nid", ""))
            if n:
                n.title = payload.get("title", n.title)
                n.body = payload.get("body", n.body)
                n.updated = payload.get("updated", n.updated)
            else:
                self._notes.insert(0, Note.from_dict(payload))
            self._save()
            return
        if event_type == "note_delete":
            self._notes = [n for n in self._notes if n.nid != payload.get("nid")]
            self._save()

    def _emit(self, event_type: str, payload: dict):
        if self._change_listener:
            self._change_listener(event_type, payload)
