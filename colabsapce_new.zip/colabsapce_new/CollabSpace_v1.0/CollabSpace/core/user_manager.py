"""core/user_manager.py — user authentication and session support."""
import hashlib
from data.storage import Storage

class UserManager:
    def __init__(self, storage: Storage):
        self._storage = storage
        self._users = {u['username']: u for u in self._storage.load('users')}
        self._current = None
        self._restore_session()

    def _hash(self, password):
        return hashlib.sha256(password.encode('utf-8')).hexdigest()

    def register(self, username, password):
        username = username.strip().lower()
        if not username or not password:
            raise ValueError('Username and password cannot be empty')
        if username in self._users:
            raise ValueError('Username already exists')
        user = {
            'username': username,
            'password': self._hash(password),
            'role': 'user',
            'projects': {}
        }
        self._users[username] = user
        self._save()
        return user

    def authenticate(self, username, password):
        username = username.strip().lower()
        u = self._users.get(username)
        if u and u['password'] == self._hash(password):
            self._current = u
            self._save_session(username)
            return True
        return False

    def current_user(self):
        return self._current

    def logout(self):
        self._current = None
        self._save_session(None)

    def _save(self):
        self._storage.save_all('users', list(self._users.values()))

    def _save_session(self, username):
        self._storage.save_all('session', [{'username': username}] if username else [])

    def _restore_session(self):
        session = self._storage.load('session')
        if not session:
            return
        username = (session[0].get('username') or '').strip().lower()
        if username and username in self._users:
            self._current = self._users[username]

    def list_users(self):
        return list(self._users.values())
