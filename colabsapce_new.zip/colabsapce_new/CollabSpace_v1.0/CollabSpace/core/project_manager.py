"""core/project_manager.py"""
import uuid, os, hashlib
from datetime import datetime
from data.storage import Storage

NS = "projects"

COLORS = ["#7c6af7","#3dcfb0","#f0c060","#c97bf7","#f07840","#4a9eff"]

class Project:
    def __init__(
        self,
        pid,
        name,
        desc,
        created,
        color="#7c6af7",
        language="python",
        path="",
        owner="",
        acl=None,
        visibility="private",
        password_hash=None,
    ):
        self.pid = pid; self.name = name; self.desc = desc
        self.created = created; self.color = color; self.language = language; self.path = path
        self.owner = owner
        self.acl = acl or ({owner: "owner"} if owner else {})
        self.visibility = visibility or "private"
        self.password_hash = password_hash

    def to_dict(self):
        return dict(pid=self.pid,name=self.name,desc=self.desc,
                    created=self.created,color=self.color,language=self.language,
                    path=self.path, owner=self.owner, acl=self.acl,
                    visibility=self.visibility, password_hash=self.password_hash)

    @classmethod
    def from_dict(cls, d):
        return cls(d.get("pid",str(uuid.uuid4())), d.get("name","Unnamed"),
                   d.get("desc",""), d.get("created",""), d.get("color","#7c6af7"),
                   d.get("language","python"), d.get("path",""),
                   d.get("owner",""), d.get("acl", {}),
                   d.get("visibility","private"), d.get("password_hash"))

class ProjectManager:
    def __init__(self, storage: Storage):
        self._s = storage
        self._projects: list[Project] = [Project.from_dict(r) for r in self._s.load(NS)]

    def _hash_password(self, password: str) -> str:
        return hashlib.sha256(password.encode("utf-8")).hexdigest()

    def create(
        self,
        name,
        desc="",
        color="#7c6af7",
        path="",
        owner="",
        visibility="private",
        password: str | None = None,
    ) -> Project:
        name = name.strip()
        if not name: raise ValueError("Name cannot be empty.")
        if any(p.name.lower()==name.lower() for p in self._projects):
            raise ValueError(f"Project '{name}' already exists.")
        if path:
            os.makedirs(path, exist_ok=True)
        owner_norm = (owner or "").strip().lower()
        visibility = (visibility or "private").strip().lower()
        if visibility not in ("public", "private"):
            raise ValueError("visibility must be 'public' or 'private'")

        password_hash = None
        if visibility == "private" and password:
            password_hash = self._hash_password(password)

        p = Project(
            str(uuid.uuid4()),
            name,
            desc.strip(),
            datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            color,
            "python",
            path,
            owner=owner_norm,
            visibility=visibility,
            password_hash=password_hash,
        )
        self._projects.append(p); self._save(); return p

    def all(self) -> list[Project]:
        return list(reversed(self._projects))

    def get(self, pid) -> Project | None:
        return next((p for p in self._projects if p.pid==pid), None)

    def delete(self, pid) -> bool:
        before = len(self._projects)
        self._projects = [p for p in self._projects if p.pid!=pid]
        if len(self._projects)<before: self._save(); return True
        return False

    def rename(self, pid, name) -> bool:
        p = self.get(pid)
        if p and name.strip(): p.name=name.strip(); self._save(); return True
        return False

    def grant(self, pid, username, access):
        p = self.get(pid)
        if not p: raise ValueError('Project not found')
        access = access.lower()
        if access not in ('read','write','owner'):
            raise ValueError('Access must be read/write/owner')
        username = (username or "").strip().lower()
        p.acl[username] = access
        self._save()

    def revoke(self, pid, username):
        p = self.get(pid)
        if not p: raise ValueError('Project not found')
        username = (username or "").strip().lower()
        if username in p.acl and username!=p.owner:
            del p.acl[username]; self._save(); return True
        return False

    def can_access(self, pid, username, access='read', password: str | None = None):
        p = self.get(pid)
        if not p: return False
        username = (username or "").strip().lower()

        # Owner always has access.
        if p.owner == username: return True

        # Public projects are readable by everyone.
        if p.visibility == "public":
            if access == "read":
                return True
            # For writes, still require explicit permission.
            mode = p.acl.get(username)
            if not mode:
                return False
            if access == "write":
                return mode in ("write", "owner")
            return False

        # Private projects.
        mode = p.acl.get(username)
        if not mode:
            # Allow read access if the caller provides the correct project password.
            if access == "read" and password and self.verify_project_password(pid, password):
                return True
            return False
        if access == 'read': return mode in ('read','write','owner')
        if access == 'write': return mode in ('write','owner')
        return False

    def verify_project_password(self, pid, password: str) -> bool:
        """Check whether the provided password unlocks the private project."""
        p = self.get(pid)
        if not p or p.visibility != "private" or not p.password_hash:
            return False
        return self._hash_password(password) == p.password_hash


    def _save(self):
        self._s.save_all(NS, [p.to_dict() for p in self._projects])
