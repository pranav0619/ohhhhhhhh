"""Local TLS WebSocket invite server."""
import asyncio
import json
import threading

try:
    import websockets
except Exception:  # pragma: no cover
    websockets = None


class CollabServer:
    def __init__(self, on_invite, on_sync_event):
        self._on_invite = on_invite
        self._on_sync_event = on_sync_event
        self._loop = None
        self._thread = None
        self._clients = set()
        self.port = 46874

    def start(self):
        if websockets is None:
            return
        if self._thread and self._thread.is_alive():
            return
        self._thread = threading.Thread(target=self._run_loop, daemon=True)
        self._thread.start()

    def stop(self):
        if self._loop:
            self._loop.call_soon_threadsafe(self._loop.stop)

    def broadcast(self, raw: str):
        if not self._loop or not self._clients:
            return
        asyncio.run_coroutine_threadsafe(self._broadcast(raw), self._loop)

    async def _broadcast(self, raw: str):
        stale = []
        for ws in list(self._clients):
            try:
                await ws.send(raw)
            except Exception:
                stale.append(ws)
        for ws in stale:
            self._clients.discard(ws)

    def _run_loop(self):
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        self._loop.run_until_complete(self._serve())
        self._loop.run_forever()

    async def _serve(self):
        async def _handler(websocket):
            self._clients.add(websocket)
            try:
                async for raw in websocket:
                    try:
                        msg = json.loads(raw)
                    except Exception:
                        continue
                    if msg.get("kind") == "invite":
                        accepted = self._on_invite(msg)
                        await websocket.send(json.dumps({"kind": "invite_result", "accepted": bool(accepted)}))
                    elif msg.get("kind") == "sync_event":
                        self._on_sync_event(raw)
            finally:
                self._clients.discard(websocket)
        await websockets.serve(_handler, "0.0.0.0", self.port)
