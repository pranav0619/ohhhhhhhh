"""core/members.py — runtime team members + activity log."""
from datetime import datetime
import uuid

MEMBERS = []

_activity = []

def get_members():
    return list(MEMBERS)

def member_by_id(uid):
    return next((m for m in MEMBERS if m["id"]==uid), None)

def add_member(name, role="Member", status="online", task="", avatar=None, color="#7c6af7"):
    if not name.strip():
        raise ValueError("Name cannot be empty")
    uid = str(uuid.uuid4())
    initials = "".join([p[:1].upper() for p in name.strip().split()])[:2] or "??"
    member = {
        "id": uid,
        "name": name.strip(),
        "role": role.strip() or "Member",
        "avatar": avatar or initials,
        "color": color,
        "status": status,
        "task": task.strip(),
    }
    MEMBERS.append(member)
    return member

def update_member(uid, **fields):
    member = member_by_id(uid)
    if not member:
        raise ValueError("Member not found")
    for key, value in fields.items():
        if key in member and value is not None:
            member[key] = value
    return member

def remove_member(uid):
    global MEMBERS
    member = member_by_id(uid)
    if not member:
        raise ValueError("Member not found")
    MEMBERS = [m for m in MEMBERS if m["id"] != uid]
    return member

def get_activity():
    return list(_activity)

def add_activity(user, action, atype="edit"):
    _activity.insert(0, {"id":str(uuid.uuid4()),"user":user,
                          "action":action,"time":"just now","type":atype})
    if len(_activity) > 50: _activity.pop()
