"""core/file_manager.py"""
import os, shutil
from pathlib import Path

BASE = Path.home() / ".collabspace" / "projects"

EXTS = {".py":"Python",".txt":"Text",".md":"Markdown",
        ".json":"JSON",".csv":"CSV",".html":"HTML",".css":"CSS",".js":"JavaScript"}

ICONS = {".py":"🐍",".txt":"📄",".md":"📝",".json":"{}",
         ".csv":"📊",".html":"🌐",".css":"🎨",".js":"JS"}

class FileManager:
    def __init__(self):
        self._pid = None; self._root = None

    def set_project(self, pid, path=""):
        self._pid = pid
        if path:
            self._root = Path(path)
            self._root.mkdir(parents=True, exist_ok=True)
        else:
            # fallback to old way
            self._root = Path.home() / ".collabspace" / "projects" / pid
            self._root.mkdir(parents=True, exist_ok=True)

    @property
    def root(self): return self._root

    def list_files(self) -> list[dict]:
        self._req()
        result = []
        for e in sorted(self._root.iterdir()):
            if e.is_file():
                ext = e.suffix.lower()
                result.append(dict(name=e.name, path=str(e), ext=ext,
                                   size=e.stat().st_size,
                                   lang=EXTS.get(ext,"Other"),
                                   icon=ICONS.get(ext,"📄")))
        return result

    def read(self, name) -> str:
        self._req()
        return self._safe(name).read_text(encoding="utf-8", errors="replace")

    def write(self, name, content):
        self._req()
        self._safe(name).write_text(content, encoding="utf-8")

    def diff(self, name, content):
        import difflib
        self._req()
        old = ""
        try:
            old = self.read(name)
        except FileNotFoundError:
            pass
        return "\n".join(difflib.unified_diff(old.splitlines(), content.splitlines(),
                                            fromfile=f"{name}.old", tofile=name, lineterm=""))

    def apply_patch(self, name, patch):
        import difflib
        self._req()
        target = self._safe(name)
        data = ''
        try:
            if target.exists():
                old = target.read_text(encoding='utf-8').splitlines()
            else:
                old = []
            new = list(difflib.restore(patch.splitlines(), 2))
            data = "\n".join(new) + "\n"
            target.write_text(data, encoding='utf-8')
            return True
        except Exception as e:
            raise IOError(f"Patch apply failed: {e}")

    def create(self, name, content="") -> dict:
        self._req()
        name = self._san(name)
        p = self._safe(name)
        if p.exists(): raise FileExistsError(f"'{name}' already exists.")
        p.write_text(content, encoding="utf-8")
        ext = p.suffix.lower()
        return dict(name=name, path=str(p), ext=ext,
                    size=len(content.encode()), lang=EXTS.get(ext,"Other"),
                    icon=ICONS.get(ext,"📄"))

    def rename(self, old, new):
        self._req()
        o = self._safe(old); n = self._safe(self._san(new))
        if not o.exists(): raise FileNotFoundError(f"'{old}' not found.")
        if n.exists():     raise FileExistsError(f"'{new}' already exists.")
        o.rename(n)

    def delete(self, name):
        self._req()
        p = self._safe(name)
        if not p.exists(): raise FileNotFoundError(f"'{name}' not found.")
        p.unlink()

    def exists(self, name) -> bool:
        if not self._root: return False
        return (self._root / name).exists()

    def delete_project_folder(self, pid):
        folder = BASE / pid
        if folder.exists(): shutil.rmtree(folder, ignore_errors=True)

    def _req(self):
        if not self._root: raise RuntimeError("No project set.")

    def _safe(self, name):
        c = (self._root / name).resolve()
        if not str(c).startswith(str(self._root.resolve())):
            raise ValueError(f"Invalid filename: {name}")
        return c

    def sync_with_peer(self, name, peer_content):
        self._req()
        local = ''
        try:
            local = self.read(name)
        except FileNotFoundError:
            local = ''
        if local == peer_content:
            return 'up-to-date'
        diff = self.diff(name, peer_content)
        self.write(name, peer_content)
        return diff

    @staticmethod
    def _san(name):
        name = name.strip().replace("/","_").replace("\\","_")
        if not name: raise ValueError("Empty filename.")
        return name
