"""Realtime collaboration sync protocol helpers."""
import json
import time
import uuid


class CollabSync:
    def __init__(self, task_manager, note_manager, add_activity_cb):
        self._tm = task_manager
        self._nm = note_manager
        self._add_activity = add_activity_cb
        self._send_cb = None
        self._permission = "viewer"
        self._project_id = ""

    def attach_sender(self, send_cb):
        self._send_cb = send_cb

    def set_session(self, project_id: str, permission: str):
        self._project_id = project_id
        self._permission = permission

    def emit_local(self, event_type: str, payload: dict):
        if not self._send_cb or not self._project_id:
            return
        if payload.get("project_id") and payload.get("project_id") != self._project_id:
            return
        msg = {
            "id": str(uuid.uuid4()),
            "kind": "sync_event",
            "event_type": event_type,
            "payload": payload,
            "project_id": self._project_id,
            "ts": int(time.time()),
        }
        self._send_cb(json.dumps(msg))

    def apply_remote_raw(self, raw: str):
        try:
            msg = json.loads(raw)
        except Exception:
            return
        if msg.get("kind") != "sync_event":
            return
        if self._project_id and msg.get("project_id") != self._project_id:
            return
        et = msg.get("event_type", "")
        payload = msg.get("payload", {})
        if et.startswith("note_"):
            self._nm.apply_remote(et, payload)
        elif et.startswith("task_"):
            self._tm.apply_remote(et, payload)
        self._add_activity("Teammate", f"synced {et.replace('_', ' ')}", "edit")

    def can_write(self) -> bool:
        return self._permission in ("editor", "admin")
