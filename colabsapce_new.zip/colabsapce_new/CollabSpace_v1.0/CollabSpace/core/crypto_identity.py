"""Local identity and beacon signing helpers."""
import base64
import json

from data.storage import Storage

try:
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
except Exception:  # pragma: no cover
    Ed25519PrivateKey = None
    Ed25519PublicKey = None
    serialization = None


class IdentityManager:
    def __init__(self, storage: Storage):
        self._s = storage
        self._keys = self._s.load("identity_keys")
        self._private = None
        self._public = None
        self._ensure_keys()

    def _ensure_keys(self):
        if Ed25519PrivateKey is None:
            raise RuntimeError("cryptography dependency is required for signed beacons")
        if self._keys and self._keys[0].get("private_key"):
            priv_b64 = self._keys[0]["private_key"]
            raw = base64.b64decode(priv_b64.encode("ascii"))
            self._private = Ed25519PrivateKey.from_private_bytes(raw)
            self._public = self._private.public_key()
            return
        self._private = Ed25519PrivateKey.generate()
        self._public = self._private.public_key()
        priv_raw = self._private.private_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PrivateFormat.Raw,
            encryption_algorithm=serialization.NoEncryption(),
        )
        pub_raw = self._public.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )
        self._keys = [{
            "private_key": base64.b64encode(priv_raw).decode("ascii"),
            "public_key": base64.b64encode(pub_raw).decode("ascii"),
        }]
        self._s.save_all("identity_keys", self._keys)

    def public_key_b64(self) -> str:
        pub_raw = self._public.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )
        return base64.b64encode(pub_raw).decode("ascii")

    def sign_payload(self, payload: dict) -> str:
        body = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
        sig = self._private.sign(body)
        return base64.b64encode(sig).decode("ascii")

    @staticmethod
    def verify_payload(payload: dict, signature_b64: str, public_key_b64: str) -> bool:
        if Ed25519PublicKey is None:
            return False
        try:
            body = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
            sig = base64.b64decode(signature_b64.encode("ascii"))
            pub = Ed25519PublicKey.from_public_bytes(base64.b64decode(public_key_b64.encode("ascii")))
            pub.verify(sig, body)
            return True
        except Exception:
            return False
