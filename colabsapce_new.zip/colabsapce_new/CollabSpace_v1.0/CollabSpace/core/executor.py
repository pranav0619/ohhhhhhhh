"""core/executor.py — runs code in a subprocess."""
import subprocess, threading, sys, os, tempfile, webbrowser
from typing import Callable

class CodeExecutor:
    def __init__(self):
        self._proc = None; self._thread = None; self._running = False

    @property
    def is_running(self): return self._running

    def run(self, source, on_output=None, on_done=None, lang='py') -> bool:
        if self._running: return False
        self._running = True
        self._thread = threading.Thread(target=self._run,
                                        args=(source, lang, on_output, on_done), daemon=True)
        self._thread.start(); return True

    def send_input(self, text):
        if self._proc and self._running:
            try:
                self._proc.stdin.write(text + '\n')
                self._proc.stdin.flush()
            except Exception:
                pass

    def terminate(self):
        if self._proc and self._running:
            try: self._proc.terminate()
            except OSError: pass

    def _run(self, source, lang, on_output, on_done):
        tmp = None
        try:
            if lang == 'html':
                tmp = tempfile.NamedTemporaryFile(mode="w", suffix=".html", delete=False,
                                                  encoding="utf-8", prefix="cs_")
                tmp.write(source); tmp.close()
                webbrowser.open(f'file://{tmp.name}')
                if on_output: on_output("Opened in browser\n")
                try: os.unlink(tmp.name)
                except OSError: pass
                tmp = None
                self._running = False
                if on_done: on_done()
                return
            elif lang == 'js':
                suffix = '.js'
                cmd = ['node']
            else:  # default to py
                suffix = '.py'
                cmd = [sys.executable]

            tmp = tempfile.NamedTemporaryFile(mode="w", suffix=suffix, delete=False,
                                              encoding="utf-8", prefix="cs_")
            tmp.write(source); tmp.close()
            cmd.append(tmp.name)

            self._proc = subprocess.Popen(cmd,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                stdin=subprocess.PIPE,
                text=True, encoding="utf-8", errors="replace")
            for line in self._proc.stdout:
                if on_output: on_output(line)
            self._proc.wait(); rc = self._proc.returncode
        except Exception as e:
            if on_output: on_output(f"[Executor] {e}\n")
        finally:
            self._running = False
            if on_done: on_done()
            if tmp:
                try: os.unlink(tmp.name)
                except OSError: pass
        if on_done: on_done(rc)
