"""ui/dashboard.py — root UI container, wires all panels."""
import tkinter as tk
from tkinter import messagebox, simpledialog, filedialog as fd
import json

from core.project_manager import ProjectManager, COLORS as PROJ_COLORS
from core.task_manager    import TaskManager
from core.note_manager    import NoteManager
from core.file_manager    import FileManager
from core.executor        import CodeExecutor
from core.user_manager    import UserManager
from core.members         import add_activity, get_members
from core.friends         import FriendsManager
from core.crypto_identity import IdentityManager
from core.discovery_service import DiscoveryService
from core.collab_server import CollabServer
from core.collab_client import CollabClient
from core.collab_sync import CollabSync

from ui.theme           import *
from ui.topbar          import TopBar
from ui.nav_rail        import NavRail
from ui.file_tree       import FileTree
from ui.editor_panel    import EditorPanel
from ui.task_board      import TaskBoard
from ui.notes_panel     import NotesPanel
from ui.chat_panel      import ChatPanel
from ui.team_panel      import TeamPanel
from ui.activity_panel  import ActivityPanel
from ui.right_panel     import RightPanel
from ui.settings_panel  import SettingsPanel
from ui.dialogs         import ask_text
from ui.nearby_friends_overlay import NearbyFriendsOverlay
from ui.invite_teammate_dialog import InviteTeammateDialog


class Dashboard(tk.Frame):
    def __init__(self, parent, project_manager: ProjectManager,
                 task_manager: TaskManager, note_manager: NoteManager,
                 file_manager: FileManager, executor: CodeExecutor,
                 user_manager: UserManager):
        super().__init__(parent, bg=BG)

        self._pm = project_manager
        self._tm = task_manager
        self._nm = note_manager
        self._fm = file_manager
        self._ex = executor
        self._um = user_manager

        self._active_proj  = None
        self._active_panel = "editor"
        self._friends = FriendsManager(self._um._storage)
        self._identity = IdentityManager(self._um._storage)
        self._collab_server = CollabServer(self._handle_invite, self._handle_sync_raw)
        self._collab_client = CollabClient(self._handle_sync_raw, self._on_invite_result)
        self._collab_sync = CollabSync(self._tm, self._nm, add_activity)
        self._discovery = None

        self._build_menu(parent)
        self._prompt_login()
        self._build_layout()
        self._load_initial_data()
        self._start_local_services()
        self._tm.set_change_listener(self._collab_sync.emit_local)
        self._nm.set_change_listener(self._collab_sync.emit_local)

    def _prompt_login(self):
        if self._um.current_user():
            return
        while True:
            dlg = LoginDialog(self)
            if dlg.result is None:
                self.master.destroy(); return
            mode, username, password = dlg.result
            try:
                if mode == 'login':
                    ok = self._um.authenticate(username, password)
                    if not ok:
                        messagebox.showerror('Login Failed', 'Invalid username or password')
                        continue
                    add_activity(username, 'logged in', 'info')
                    break
                else:
                    self._um.register(username, password)
                    messagebox.showinfo('Registered', 'User created, please login.')
            except ValueError as e:
                messagebox.showerror('Error', str(e))

    # ══════════════════════════════════════════════════════════════════════════
    # Menu
    # ══════════════════════════════════════════════════════════════════════════
    def _build_menu(self, root):
        mb = tk.Menu(root, bg=PANEL2, fg=TEXT,
                     activebackground=ACCENT, activeforeground="white",
                     tearoff=False, bd=0)
        root.config(menu=mb)

        # File
        fm = tk.Menu(mb, bg=PANEL2, fg=TEXT, activebackground=ACCENT,
                     activeforeground="white", tearoff=False)
        fm.add_command(label="New Project…",  command=self.new_project)
        fm.add_command(label="New File…",     command=self._new_file_menu)
        fm.add_separator()
        fm.add_command(label="Save  Ctrl+S",  command=self._save_current)
        fm.add_separator()
        fm.add_command(label="Exit",          command=root.destroy)
        mb.add_cascade(label="File", menu=fm)

        # Project
        pm = tk.Menu(mb, bg=PANEL2, fg=TEXT, activebackground=ACCENT,
                     activeforeground="white", tearoff=False)
        pm.add_command(label="Rename Project…", command=self._rename_project)
        pm.add_separator()
        pm.add_command(label="Delete Project",  command=self._delete_project)
        mb.add_cascade(label="Project", menu=pm)

        # View
        vm = tk.Menu(mb, bg=PANEL2, fg=TEXT, activebackground=ACCENT,
                     activeforeground="white", tearoff=False)
        vm.add_command(label="Toggle Console", command=self._toggle_console)
        vm.add_command(label="Clear Console",  command=self._clear_console)
        vm.add_separator()
        vm.add_command(label="Toggle Left Sidebar", command=self._toggle_left_sidebar)
        vm.add_command(label="Toggle Right Sidebar", command=self._toggle_right_sidebar)
        vm.add_separator()
        for key, label in [("editor","Editor"),("tasks","Tasks"),
                           ("notes","Notes"),("chat","Chat"),("members","Team"),
                           ("activity","Activity"),("settings","Settings")]:
            vm.add_command(label=label,
                           command=lambda k=key: self._switch_panel(k))
        mb.add_cascade(label="View", menu=vm)

        # Help
        hm = tk.Menu(mb, bg=PANEL2, fg=TEXT, activebackground=ACCENT,
                     activeforeground="white", tearoff=False)
        hm.add_command(label="Keyboard Shortcuts", command=self._show_shortcuts)
        hm.add_command(label="About CollabSpace",  command=self._show_about)
        mb.add_cascade(label="Help", menu=hm)

    # ══════════════════════════════════════════════════════════════════════════
    # Layout
    # ══════════════════════════════════════════════════════════════════════════
    def _build_layout(self):
        # Top bar
        self._topbar = TopBar(self, self)
        self._topbar.pack(fill=tk.X)
        tk.Frame(self, bg=BORDER, height=1).pack(fill=tk.X)

        # Body row
        body = tk.Frame(self, bg=BG)
        body.pack(fill=tk.BOTH, expand=True)

        self._left_visible = True
        self._right_visible = True

        # Left: nav + file tree (collapsible)
        self._left_sidebar = tk.Frame(body, bg=BG)
        self._nav = NavRail(self._left_sidebar, self._switch_panel)
        self._nav.pack(side=tk.LEFT, fill=tk.Y)
        tk.Frame(self._left_sidebar, bg=BORDER, width=1).pack(side=tk.LEFT, fill=tk.Y)
        self._file_tree = FileTree(self._left_sidebar, self._fm, self._on_open_file)
        self._file_tree.pack(side=tk.LEFT, fill=tk.Y)
        tk.Frame(self._left_sidebar, bg=BORDER, width=1).pack(side=tk.LEFT, fill=tk.Y)

        self._left_grip = tk.Frame(body, bg=PANEL2, width=12)
        self._left_grip.pack_propagate(False)
        self._left_grip_lbl = tk.Label(
            self._left_grip,
            text="⟨",
            bg=PANEL2,
            fg=DIM,
            font=("Segoe UI", 11, "bold"),
            cursor="hand2",
        )
        self._left_grip_lbl.pack(expand=True)
        self._left_grip_lbl.bind("<Button-1>", lambda _e: self._toggle_left_sidebar())

        self._left_sidebar.pack(side=tk.LEFT, fill=tk.Y)
        self._left_grip.pack(side=tk.LEFT, fill=tk.Y)

        # Centre content frame (swapped by nav)
        self._center = tk.Frame(body, bg=BG)
        self._center.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self._right = RightPanel(body)
        self._right_grip = tk.Frame(body, bg=PANEL2, width=12)
        self._right_grip.pack_propagate(False)
        self._right_grip_lbl = tk.Label(
            self._right_grip,
            text="⟩",
            bg=PANEL2,
            fg=DIM,
            font=("Segoe UI", 11, "bold"),
            cursor="hand2",
        )
        self._right_grip_lbl.pack(expand=True)
        self._right_grip_lbl.bind("<Button-1>", lambda _e: self._toggle_right_sidebar())

        self._right_grip.pack(side=tk.LEFT, fill=tk.Y)
        self._right.pack(side=tk.LEFT, fill=tk.Y)

        # Build all panels (hidden until selected)
        self._editor   = EditorPanel(self._center, self._ex, self._on_save)
        self._tasks    = TaskBoard(self._center, self._tm,
                                   lambda: self._active_proj)
        self._notes    = NotesPanel(self._center, self._nm,
                                    lambda: self._active_proj)
        self._chat     = ChatPanel(self._center, self._um.current_user)
        self._team     = TeamPanel(self._center, self._tm,
                                   lambda: self._active_proj,
                                   on_update=self._refresh_all)
        self._activity = ActivityPanel(self._center)
        self._settings = SettingsPanel(self._center,
                                         on_update=self._refresh_all,
                                         on_share=self._grant_project_access,
                                         friends_manager=self._friends)
        self._nearby_overlay = NearbyFriendsOverlay(self, self._on_nearby_add_to_team, self._on_nearby_dismiss)

        self._panels = {
            "editor":   self._editor,
            "tasks":    self._tasks,
            "notes":    self._notes,
            "chat":     self._chat,
            "members":  self._team,
            "activity": self._activity,
            "settings": self._settings,
        }
        # Show editor by default
        self._switch_panel("editor")

    def _toggle_left_sidebar(self):
        if self._left_visible:
            self._left_sidebar.pack_forget()
            self._left_grip_lbl.config(text="⟩")
        else:
            self._left_sidebar.pack(side=tk.LEFT, fill=tk.Y, before=self._left_grip)
            self._left_grip_lbl.config(text="⟨")
        self._left_visible = not self._left_visible

    def _toggle_right_sidebar(self):
        if self._right_visible:
            self._right.pack_forget()
            self._right_grip_lbl.config(text="⟨")
        else:
            self._right.pack(side=tk.LEFT, fill=tk.Y, after=self._right_grip)
            self._right_grip_lbl.config(text="⟩")
        self._right_visible = not self._right_visible

    # ══════════════════════════════════════════════════════════════════════════
    # Initial demo data
    # ══════════════════════════════════════════════════════════════════════════
    def _load_initial_data(self):
        """Leave space for user to create projects/teams; no auto-demo stats."""
        projects = self._pm.all()
        self._refresh_topbar()
        if projects:
            current = self._um.current_user()
            # Avoid switching to a project the user can't access.
            if current:
                for p in projects:
                    if self._pm.can_access(p.pid, current["username"], "read"):
                        self.switch_project(p.pid)
                        break


    def _seed_demo(self):
        import os
        from core.project_manager import COLORS as PC
        # Project 1
        p1 = self._pm.create("Machine Learning Basics",
                              "Study group for ML fundamentals", color=PC[0])
        self._fm.set_project(p1.pid)
        self._fm.create("main.py",
'# Machine Learning Basics\nimport math\n\ndef linear_regression(X, y):\n    """Simple linear regression."""\n    n = len(X)\n    mx = sum(X)/n; my = sum(y)/n\n    num = sum((X[i]-mx)*(y[i]-my) for i in range(n))\n    den = sum((X[i]-mx)**2 for i in range(n))\n    slope = num/den\n    intercept = my - slope*mx\n    return slope, intercept\n\nif __name__ == "__main__":\n    X = [1,2,3,4,5]\n    y = [2.1,3.9,6.2,7.8,10.1]\n    slope, intercept = linear_regression(X, y)\n    print(f"Slope: {slope:.3f}")\n    print(f"Intercept: {intercept:.3f}")\n    print("Model trained successfully!")\n')
        self._fm.create("utils.py",
'# Utility functions\n\ndef normalize(data):\n    """Min-max normalization."""\n    mn, mx = min(data), max(data)\n    return [(x-mn)/(mx-mn) for x in data]\n\ndef accuracy(preds, labels):\n    correct = sum(p==l for p,l in zip(preds,labels))\n    return correct / len(labels)\n\nif __name__ == "__main__":\n    data = [10, 20, 30, 40, 50]\n    print("Normalized:", normalize(data))\n')
        self._fm.create("README.md",
'# ML Basics Project\n\nA collaborative study project.\n\n## Topics\n- Linear Regression\n- Classification\n- Neural Networks\n\n## Run\n```\npython main.py\n```\n')
        # Tasks
        self._tm.add(p1.pid,"Implement gradient descent","Add SGD optimizer","high","u1")
        t2=self._tm.add(p1.pid,"Write unit tests","Cover all utility functions","medium","u2")
        self._tm.move(t2.tid,"in_progress")
        t3=self._tm.add(p1.pid,"Add data visualizations","Plot training curves","medium","u4")
        self._tm.move(t3.tid,"in_progress")
        t4=self._tm.add(p1.pid,"Document API","Write docstrings","low","u3")
        t5=self._tm.add(p1.pid,"Optimize memory","Profile and improve","high","u1")
        t6=self._tm.add(p1.pid,"Setup CI pipeline","GitHub Actions","medium","u2")
        self._tm.move(t6.tid,"done")
        # Notes
        self._nm.create(p1.pid,"Meeting Notes – March 20",
                        "# Sprint Planning\n\n- Focus on gradient descent this week\n- Priya writes tests\n- Sneha handles visualization\n\n## Next Steps\n1. Review linear algebra\n2. Set up shared notebook\n")
        self._nm.create(p1.pid,"Resources",
                        "## Useful Links\n\n- Andrew Ng ML Course\n- Scikit-learn docs\n- NumPy documentation\n\n## Books\n- Pattern Recognition (Bishop)\n- Elements of Statistical Learning\n")

        # Project 2
        p2 = self._pm.create("Web Scraper",
                              "Automated data collection tool", color=PC[1])
        self._fm.set_project(p2.pid)
        self._fm.create("scraper.py",
'# Web Scraper\nimport urllib.request\n\ndef fetch_page(url):\n    """Fetch a webpage and return HTML."""\n    try:\n        with urllib.request.urlopen(url) as r:\n            return r.read().decode("utf-8")\n    except Exception as e:\n        return f"Error: {e}"\n\ndef extract_title(html):\n    """Extract page title from HTML."""\n    s = html.find("<title>")\n    e = html.find("</title>")\n    if s != -1 and e != -1:\n        return html[s+7:e].strip()\n    return "No title found"\n\nif __name__ == "__main__":\n    url = "http://example.com"\n    print(f"Fetching: {url}")\n    html = fetch_page(url)\n    title = extract_title(html)\n    print(f"Title: {title}")\n    print(f"Size: {len(html)} chars")\n')
        self._fm.create("config.json",
'{\n  "targets": [\n    "http://example.com",\n    "http://httpbin.org/get"\n  ],\n  "delay": 1.5,\n  "max_retries": 3,\n  "output_dir": "./data"\n}\n')
        self._tm.add(p2.pid,"Handle rate limiting","Exponential backoff","high","u2")
        t=self._tm.add(p2.pid,"Export to CSV","Save scraped data","low","u3")
        self._tm.move(t.tid,"done")
        self._nm.create(p2.pid,"Scraping Strategy",
                        "# Approach\n\nUse polite crawling:\n- Respect robots.txt\n- Add delays\n- Cache responses\n\nTarget: news aggregators, job boards\n")

    # ══════════════════════════════════════════════════════════════════════════
    # Panel switching
    # ══════════════════════════════════════════════════════════════════════════
    def _switch_panel(self, key):
        self._active_panel = key
        for k, panel in self._panels.items():
            if k == key:
                panel.pack(fill=tk.BOTH, expand=True)
                # Refresh on show
                if hasattr(panel, "refresh"): panel.refresh()
            else:
                panel.pack_forget()
        self._nav.select(key)

    # ══════════════════════════════════════════════════════════════════════════
    # Project actions
    # ══════════════════════════════════════════════════════════════════════════
    def new_project(self):
        dlg = _NewProjectDialog(self)
        if dlg.result:
            name, desc, color, visibility, password = dlg.result
            path = fd.askdirectory(title="Select project location")
            if not path:
                return
            try:
                current = self._um.current_user()
                if not current:
                    messagebox.showerror("Login Required", "Please login first.")
                    return
                visibility = (visibility or "private").strip().lower()
                password = (password or "").strip()
                if visibility == "private" and not password:
                    messagebox.showerror("Missing Password", "Private projects require a password.")
                    return
                p = self._pm.create(
                    name,
                    desc=desc,
                    color=color,
                    path=path,
                    owner=current["username"],
                    visibility=visibility,
                    password=password if visibility == "private" else None,
                )
                add_activity("You", f"created project '{p.name}'", "task")
                self._refresh_topbar()
                self.switch_project(p.pid)
                self._editor.console_append(f"  ✔ Project '{p.name}' created at {path}.\n","success")
            except ValueError as e:
                messagebox.showerror("Error", str(e))

    def switch_project(self, pid):
        p = self._pm.get(pid)
        if not p: return
        current = self._um.current_user()
        if not current:
            messagebox.showerror("Login Required", "Please login first.")
            return

        username = (current.get("username") or "").strip().lower()
        if not self._pm.can_access(pid, username, "read"):
            # If this is a private project protected by a password, ask for it.
            if getattr(p, "visibility", "private") == "private" and getattr(p, "password_hash", None):
                pw = ask_text(self, "Private Project", "Enter project password:", password=True)
                if pw is None:
                    return
                if self._pm.can_access(pid, username, "read", password=pw):
                    # Remember the user after successful password entry.
                    self._pm.grant(pid, username, "read")
                else:
                    messagebox.showerror("Access Denied", "Incorrect project password.")
                    return
            else:
                messagebox.showerror("Access Denied", "You do not have access to this project.")
                return
        self._active_proj = p
        self._fm.set_project(p.pid, p.path)
        self._file_tree.set_project(p)
        self._editor.set_project(p)
        if self._pm.can_access(pid, username, 'write'):
            self._editor._on_save = lambda name, content: self._fm.write(name, content)
        else:
            self._editor._on_save = None
        self._refresh_topbar()
        self._refresh_right()
        # Refresh active panel
        panel = self._panels.get(self._active_panel)
        if panel and hasattr(panel, "refresh"): panel.refresh()
        add_activity("You", f"switched to '{p.name}'", "view")

    def _rename_project(self):
        if not self._active_proj:
            messagebox.showinfo("No Project", "Select a project first."); return
        new = ask_text(self, "Rename Project", "New project name:", initialvalue=self._active_proj.name)
        if not new: return
        self._pm.rename(self._active_proj.pid, new.strip())
        self._active_proj = self._pm.get(self._active_proj.pid)
        self._refresh_topbar()
        self._editor.set_project(self._active_proj)

    def _delete_project(self):
        if not self._active_proj:
            messagebox.showinfo("No Project","Select a project first."); return
        name = self._active_proj.name
        if not messagebox.askyesno("Delete Project",
                f"Delete '{name}'?\nAll files, tasks and notes will be removed."):
            return

    def _grant_project_access(self, username, access):
        if not self._active_proj:
            raise RuntimeError('Select a project first')
        if not self._um.current_user():
            raise RuntimeError('Login required')
        if self._active_proj.owner != self._um.current_user()['username']:
            raise RuntimeError('Only project owner can share')
        self._pm.grant(self._active_proj.pid, username, access)
        self._refresh_right()

    def _refresh_topbar(self):
        projects = self._pm.all()
        pid = self._active_proj.pid if self._active_proj else None
        self._topbar.refresh_projects(projects, pid)
        self._topbar.set_avatars(get_members())
        self._refresh_right()

    def _refresh_right(self):
        proj = self._active_proj
        files = len(self._fm.list_files()) if proj and self._fm.root else 0
        tasks = self._tm.for_project(proj.pid) if proj else []
        done = len([t for t in tasks if t.status == "done"])
        member_count = len(get_members())
        self._topbar.set_stats(files, len(tasks), done, member_count)
        self._right.update_stats(proj, files, len(tasks), done, member_count)

    def _refresh_all(self):
        self._refresh_right()
        self._file_tree.refresh()
        self._team.refresh()
        self._tasks.refresh()
        self._notes.refresh()

    def _start_local_services(self):
        current = self._um.current_user()
        if not current:
            return
        self._collab_server.start()
        user_hash = FriendsManager.hash_user_id(current["username"])
        self._discovery = DiscoveryService(
            user_hash=user_hash,
            display_name=current["username"],
            version="1.0",
            device_name=self.winfo_toplevel().winfo_name(),
            identity=self._identity,
            friends_manager=self._friends,
            on_friend_online=lambda fh, info: self.after(0, self._on_friend_online, fh, info),
            on_friend_offline=lambda fh, info: self.after(0, self._on_friend_offline, fh, info),
            invite_port=self._collab_server.port,
        )
        self._discovery.start()

    def shutdown_services(self):
        if self._discovery:
            self._discovery.stop()
        self._collab_server.stop()
        self._collab_client.disconnect()

    def _on_friend_online(self, friend_hash, info):
        self._nearby_overlay.show_friend(friend_hash, info)
        add_activity(info.get("display_name", "Friend"), "is nearby on WiFi", "view")
        self._activity.refresh()

    def _on_friend_offline(self, friend_hash, info):
        self._nearby_overlay.mark_offline(friend_hash, info.get("display_name", "Friend"))
        add_activity(info.get("display_name", "Friend"), "went offline", "warn")
        self._activity.refresh()

    def _on_nearby_dismiss(self, friend_hash):
        self._friends.mark_dismissed(friend_hash)

    def _on_nearby_add_to_team(self, friend_hash, info):
        dlg = InviteTeammateDialog(self, self._pm.all())
        if not dlg.result:
            return
        pid, perm, expiry = dlg.result
        if not pid:
            return
        self._collab_client.connect(info.get("ip", "127.0.0.1"), int(info.get("port") or 46874))
        self.after(600, lambda: self._collab_client.send({
            "kind": "invite",
            "from_user": (self._um.current_user() or {}).get("username", ""),
            "project_id": pid,
            "permission": perm,
            "expiry": expiry,
        }))
        self._collab_sync.attach_sender(lambda raw: self._collab_client.send(json.loads(raw)))
        self._chat.set_sender(self._send_chat_message)
        self._collab_sync.set_session(pid, perm)
        add_activity("You", f"invited {info.get('display_name','friend')} ({perm})", "task")
        self._activity.refresh()

    def _handle_invite(self, msg: dict) -> bool:
        sender = msg.get("from_user", "Friend")
        perm = msg.get("permission", "viewer")
        accepted = messagebox.askyesno("Collab Invite", f"{sender} invited you as {perm}. Accept?")
        if accepted:
            self._collab_sync.set_session(msg.get("project_id", ""), perm)
            self._collab_sync.attach_sender(self._collab_server.broadcast)
            self._chat.set_sender(self._send_chat_message)
            add_activity(sender, "invite accepted", "task")
        else:
            add_activity(sender, "invite declined", "warn")
        self.after(0, self._activity.refresh)
        return accepted

    def _on_invite_result(self, msg: dict):
        if msg.get("accepted"):
            add_activity("Teammate", "accepted invite", "task")
        else:
            add_activity("Teammate", "declined invite", "warn")
        self.after(0, self._activity.refresh)

    def _handle_sync_raw(self, raw: str):
        try:
            msg = json.loads(raw)
        except Exception:
            msg = {}
        if msg.get("kind") == "chat_message":
            sender = msg.get("from_user", "Teammate")
            text = (msg.get("text") or "").strip()
            if text:
                self._chat.add_message(sender, text, incoming=True)
                add_activity(sender, "sent a chat message", "view")
                self.after(0, self._activity.refresh)
            return
        self._collab_sync.apply_remote_raw(raw)
        self.after(0, self._refresh_all)

    def _send_chat_message(self, text: str):
        text = (text or "").strip()
        if not text:
            return
        payload = {
            "kind": "chat_message",
            "from_user": (self._um.current_user() or {}).get("username", "You"),
            "text": text,
        }
        if self._collab_client.connected:
            self._collab_client.send(payload)
        else:
            self._collab_server.broadcast(json.dumps(payload))

    # ══════════════════════════════════════════════════════════════════════════
    # File integration
    # ══════════════════════════════════════════════════════════════════════════
    def _on_open_file(self, name, content):
        proj_id = self._active_proj.pid if self._active_proj else ""
        self._editor.open_file(name, content, proj_id)
        self._switch_panel("editor")
        add_activity("You", f"opened {name}", "view")
        self._refresh_right()

    def _on_save(self, name, content):
        self._file_tree.notify_save(name, content)
        add_activity("You", f"saved {name}", "edit")
        self._refresh_right()

    def _new_file_menu(self):
        self._file_tree._new_file()

    def _save_current(self):
        self._editor._save()

    # ══════════════════════════════════════════════════════════════════════════
    # Run callbacks
    # ══════════════════════════════════════════════════════════════════════════
    def _on_run_start(self):
        self._switch_panel("editor")
        self._editor.console_append("─" * 50 + "\n")
        self._editor.console_append("▶ Running…\n", "info")
        add_activity("You", "ran code", "edit")

    def _on_run_done(self, rc):
        tag = "success" if rc == 0 else "error"
        self._editor.console_append(f"Process exited with code {rc}\n", tag)

    # ══════════════════════════════════════════════════════════════════════════
    # Console menu delegates
    # ══════════════════════════════════════════════════════════════════════════
    def _toggle_console(self):
        self._editor.toggle_console_visibility()

    def _clear_console(self):
        self._editor.clear_console()

    # ══════════════════════════════════════════════════════════════════════════
    # Help
    # ══════════════════════════════════════════════════════════════════════════
    def _show_shortcuts(self):
        messagebox.showinfo(
            "Keyboard Shortcuts",
            "Ctrl+S        Save current file\n"
            "Ctrl+F        Toggle Find bar\n"
            "Ctrl+=        Zoom in\n"
            "Ctrl+-        Zoom out\n"
            "Tab           Insert 4 spaces\n"
            "Ctrl+Z        Undo\n"
            "Ctrl+Y        Redo\n"
            "\nFind bar:\n"
            "  Enter       Next match\n"
            "  Shift+Enter Previous match\n"
            "  Escape      Close find bar",
        )

    def _show_about(self):
        messagebox.showinfo(
            "About CollabSpace",
            "CollabSpace v1.0\n"
            "A collaborative workspace for students.\n\n"
            "Features:\n"
            "  • Multi-project workspace\n"
            "  • Multi-tab code editor\n"
            "  • Syntax highlighting\n"
            "  • Code execution (subprocess)\n"
            "  • Kanban task board\n"
            "  • Project notes\n"
            "  • File explorer\n"
            "  • Team view & activity log\n"
            "  • Find bar & font zoom\n\n"
            "Built with Python + Tkinter.",
        )


class LoginDialog(simpledialog.Dialog):
    def __init__(self, parent):
        self.result = None
        self.mode = tk.StringVar(value="login")
        self._show_password = tk.BooleanVar(value=False)
        super().__init__(parent, title="Welcome to CollabSpace")

    def body(self, master):
        master.configure(bg=PANEL2, padx=18, pady=16)

        tk.Label(
            master,
            text="Welcome back",
            bg=PANEL2,
            fg=TEXT,
            font=("Segoe UI", 14, "bold"),
        ).grid(row=0, column=0, columnspan=2, sticky=tk.W)

        tk.Label(
            master,
            text="Login to continue, or create a new account.",
            bg=PANEL2,
            fg=DIM,
            font=FONT_SM,
        ).grid(row=1, column=0, columnspan=2, sticky=tk.W, pady=(4, 14))

        tk.Label(master, text="Username", bg=PANEL2, fg=DIM, font=FONT_SM).grid(
            row=2, column=0, sticky=tk.W, pady=(0, 4)
        )
        self.username = tk.Entry(
            master,
            bg=PANEL,
            fg=TEXT,
            insertbackground=TEXT,
            relief=tk.FLAT,
            bd=6,
            font=FONT,
            width=28,
        )
        self.username.grid(row=3, column=0, columnspan=2, sticky="ew", pady=(0, 10))

        tk.Label(master, text="Password", bg=PANEL2, fg=DIM, font=FONT_SM).grid(
            row=4, column=0, sticky=tk.W, pady=(0, 4)
        )
        self.password = tk.Entry(
            master,
            bg=PANEL,
            fg=TEXT,
            insertbackground=TEXT,
            relief=tk.FLAT,
            bd=6,
            font=FONT,
            width=28,
            show="*",
        )
        self.password.grid(row=5, column=0, columnspan=2, sticky="ew")

        tk.Checkbutton(
            master,
            text="Show password",
            variable=self._show_password,
            command=self._toggle_password_visibility,
            bg=PANEL2,
            fg=DIM,
            activebackground=PANEL2,
            activeforeground=TEXT,
            selectcolor=PANEL,
            font=FONT_SM,
            bd=0,
            highlightthickness=0,
            cursor="hand2",
        ).grid(row=6, column=0, columnspan=2, sticky=tk.W, pady=(8, 12))

        mode_bar = tk.Frame(master, bg=PANEL2)
        mode_bar.grid(row=7, column=0, columnspan=2, sticky="ew", pady=(0, 2))

        tk.Label(mode_bar, text="Mode", bg=PANEL2, fg=DIM, font=FONT_SM).pack(side=tk.LEFT)
        tk.Radiobutton(
            mode_bar,
            text="Login",
            variable=self.mode,
            value="login",
            bg=PANEL2,
            fg=TEXT,
            activebackground=PANEL2,
            activeforeground=TEXT,
            selectcolor=PANEL,
            font=FONT_SM,
            cursor="hand2",
        ).pack(side=tk.LEFT, padx=(10, 8))
        tk.Radiobutton(
            mode_bar,
            text="Register",
            variable=self.mode,
            value="register",
            bg=PANEL2,
            fg=TEXT,
            activebackground=PANEL2,
            activeforeground=TEXT,
            selectcolor=PANEL,
            font=FONT_SM,
            cursor="hand2",
        ).pack(side=tk.LEFT)

        return self.username

    def _toggle_password_visibility(self):
        self.password.configure(show="" if self._show_password.get() else "*")

    def buttonbox(self):
        box = tk.Frame(self, bg=PANEL2, pady=10)
        box.pack(fill=tk.X)
        btn(box, "Continue", self.ok, bg=ACCENT, fg="white", abg=ACCENT2).pack(
            side=tk.LEFT, padx=(18, 6)
        )
        btn(box, "Cancel", self.cancel, bg=PANEL, fg=TEXT, abg=BORDER).pack(
            side=tk.LEFT, padx=6
        )
        self.bind("<Return>", self.ok)
        self.bind("<Escape>", self.cancel)

    def validate(self):
        username = self.username.get().strip()
        password = self.password.get()
        if not username or not password:
            messagebox.showerror("Missing Details", "Username and password are required.")
            return False
        return True

    def apply(self):
        self.result = (self.mode.get(), self.username.get().strip(), self.password.get())


# ── New Project Dialog ────────────────────────────────────────────────────────
class _NewProjectDialog(simpledialog.Dialog):
    def __init__(self, parent):
        self.result = None
        super().__init__(parent, title="New Project")

    def body(self, master):
        master.config(bg=PANEL2)
        for r, lbl in [(0,"Project Name:"),(1,"Description:")]:
            tk.Label(master, text=lbl, bg=PANEL2, fg=DIM,
                     font=FONT_SM).grid(row=r, column=0, sticky=tk.W, pady=6, padx=8)

        self._name = tk.Entry(master, bg=PANEL, fg=TEXT, insertbackground=TEXT,
                               relief=tk.FLAT, bd=4, font=FONT_SM, width=32)
        self._name.grid(row=0, column=1, pady=6, padx=8)

        self._desc = tk.Entry(master, bg=PANEL, fg=TEXT, insertbackground=TEXT,
                               relief=tk.FLAT, bd=4, font=FONT_SM, width=32)
        self._desc.grid(row=1, column=1, pady=6, padx=8)

        tk.Label(master, text="Colour:", bg=PANEL2, fg=DIM,
                 font=FONT_SM).grid(row=2, column=0, sticky=tk.W, pady=6, padx=8)
        from core.project_manager import COLORS as PC
        self._color = tk.StringVar(value=PC[0])
        cf = tk.Frame(master, bg=PANEL2)
        cf.grid(row=2, column=1, sticky=tk.W, pady=6, padx=8)
        for c in PC:
            rb = tk.Radiobutton(cf, variable=self._color, value=c,
                                bg=PANEL2, activebackground=PANEL2,
                                selectcolor=c, indicatoron=True)
            # Colour swatch
            sw = tk.Frame(cf, bg=c, width=22, height=22, cursor="hand2")
            sw.pack(side=tk.LEFT, padx=3)
            sw.bind("<Button-1>", lambda e, col=c: self._color.set(col))

        tk.Label(master, text="Visibility:", bg=PANEL2, fg=DIM,
                 font=FONT_SM).grid(row=3, column=0, sticky=tk.W, pady=6, padx=8)
        self._visibility = tk.StringVar(value="private")
        tk.OptionMenu(master, self._visibility, "private", "public").grid(
            row=3, column=1, sticky=tk.W, pady=6, padx=8
        )

        tk.Label(master, text="Project Password:", bg=PANEL2, fg=DIM,
                 font=FONT_SM).grid(row=4, column=0, sticky=tk.W, pady=6, padx=8)
        self._password = tk.Entry(
            master,
            bg=PANEL,
            fg=TEXT,
            insertbackground=TEXT,
            relief=tk.FLAT,
            bd=4,
            font=FONT_SM,
            width=32,
            show="*",
        )
        self._password.grid(row=4, column=1, pady=6, padx=8)

        def _sync_password_field(*_args):
            is_public = (self._visibility.get() or "").strip().lower() == "public"
            if is_public:
                self._password.delete(0, tk.END)
                self._password.configure(state=tk.DISABLED)
            else:
                self._password.configure(state=tk.NORMAL)

        self._visibility.trace_add("write", _sync_password_field)
        _sync_password_field()

        self.configure(bg=PANEL2)
        return self._name

    def buttonbox(self):
        box = tk.Frame(self, bg=PANEL2, pady=10); box.pack()
        btn(box,"Create Project", self.ok,     bg=ACCENT, fg="white", abg=ACCENT2).pack(side=tk.LEFT, padx=6)
        btn(box,"Cancel",         self.cancel, bg=PANEL,  fg=TEXT,    abg=BORDER ).pack(side=tk.LEFT, padx=6)
        self.configure(bg=PANEL2)

    def apply(self):
        name = self._name.get().strip()
        if name:
            visibility = (self._visibility.get() or "private").strip().lower()
            password = (self._password.get() or "").strip() if visibility == "private" else ""
            self.result = (name, self._desc.get().strip(), self._color.get(), visibility, password)
