"""Friend list and local collaboration metadata helpers."""
import hashlib
from data.storage import Storage


class FriendsManager:
    def __init__(self, storage: Storage):
        self._s = storage
        self._friends = self._s.load("friends")
        self._discovery = self._s.load("discovery_settings") or [{"enabled": True}]
        self._nearby_seen = self._s.load("nearby_seen")

    def all_friends(self) -> list[dict]:
        return list(self._friends)

    def add_friend(self, username: str, display_name: str, public_key: str = "") -> dict:
        username = (username or "").strip().lower()
        if not username:
            raise ValueError("Friend username is required")
        if any(f.get("username") == username for f in self._friends):
            raise ValueError("Friend already exists")
        row = {
            "username": username,
            "display_name": (display_name or username).strip(),
            "public_key": public_key or "",
            "friend_hash": self.hash_user_id(username),
        }
        self._friends.append(row)
        self._s.save_all("friends", self._friends)
        return row

    def remove_friend(self, username: str) -> bool:
        username = (username or "").strip().lower()
        before = len(self._friends)
        self._friends = [f for f in self._friends if f.get("username") != username]
        if len(self._friends) < before:
            self._s.save_all("friends", self._friends)
            return True
        return False

    def get_by_hash(self, friend_hash: str) -> dict | None:
        return next((f for f in self._friends if f.get("friend_hash") == friend_hash), None)

    def is_mutual_candidate(self, friend_hash: str) -> bool:
        return self.get_by_hash(friend_hash) is not None

    def discovery_accepts(self, friend_hash: str) -> bool:
        if self.discovery_scope() == "all":
            return True
        return self.is_mutual_candidate(friend_hash)

    def set_discovery_enabled(self, enabled: bool):
        self._discovery = [{"enabled": bool(enabled), "scope": self.discovery_scope()}]
        self._s.save_all("discovery_settings", self._discovery)

    def is_discovery_enabled(self) -> bool:
        return bool((self._discovery[0] if self._discovery else {}).get("enabled", True))

    def discovery_scope(self) -> str:
        scope = (self._discovery[0] if self._discovery else {}).get("scope", "friends")
        return "all" if scope == "all" else "friends"

    def set_discovery_scope(self, scope: str):
        enabled = self.is_discovery_enabled()
        mode = "all" if (scope or "").strip().lower() == "all" else "friends"
        self._discovery = [{"enabled": enabled, "scope": mode}]
        self._s.save_all("discovery_settings", self._discovery)

    def should_surface_nearby(self, friend_hash: str) -> bool:
        row = next((r for r in self._nearby_seen if r.get("friend_hash") == friend_hash), None)
        return not bool(row and row.get("dismissed"))

    def mark_dismissed(self, friend_hash: str):
        row = next((r for r in self._nearby_seen if r.get("friend_hash") == friend_hash), None)
        if row:
            row["dismissed"] = True
            row["online"] = True
        else:
            self._nearby_seen.append({"friend_hash": friend_hash, "dismissed": True, "online": True})
        self._s.save_all("nearby_seen", self._nearby_seen)

    def mark_reconnected(self, friend_hash: str):
        row = next((r for r in self._nearby_seen if r.get("friend_hash") == friend_hash), None)
        if row:
            row["dismissed"] = False
            row["online"] = True
        else:
            self._nearby_seen.append({"friend_hash": friend_hash, "dismissed": False, "online": True})
        self._s.save_all("nearby_seen", self._nearby_seen)

    def mark_offline(self, friend_hash: str):
        row = next((r for r in self._nearby_seen if r.get("friend_hash") == friend_hash), None)
        if row:
            row["online"] = False
            self._s.save_all("nearby_seen", self._nearby_seen)

    @staticmethod
    def hash_user_id(username: str) -> str:
        return hashlib.sha256((username or "").strip().lower().encode("utf-8")).hexdigest()
