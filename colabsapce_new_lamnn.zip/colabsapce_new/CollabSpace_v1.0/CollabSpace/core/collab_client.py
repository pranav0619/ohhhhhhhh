"""Local WebSocket collaboration client."""
import asyncio
import json
import threading

try:
    import websockets
except Exception:  # pragma: no cover
    websockets = None


class CollabClient:
    def __init__(self, on_sync_event, on_invite_result, on_connected=None):
        self._on_sync_event = on_sync_event
        self._on_invite_result = on_invite_result
        self._on_connected = on_connected
        self._loop = None
        self._thread = None
        self._ws = None
        self.connected = False

    def connect(self, host: str, port: int):
        if websockets is None:
            return
        if self.connected:
            return
        if self._thread and self._thread.is_alive():
            return
        self._thread = threading.Thread(target=self._run, args=(host, port), daemon=True)
        self._thread.start()

    def send(self, payload: dict):
        if not self._loop or not self.connected:
            return
        raw = json.dumps(payload)
        asyncio.run_coroutine_threadsafe(self._ws.send(raw), self._loop)

    def disconnect(self):
        if self._loop:
            self._loop.call_soon_threadsafe(self._loop.stop)

    def _run(self, host: str, port: int):
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        self._loop.run_until_complete(self._listen(host, port))

    async def _listen(self, host: str, port: int):
        url = f"ws://{host}:{port}"
        try:
            async with websockets.connect(url) as ws:
                self._ws = ws
                self.connected = True
                if self._on_connected:
                    self._on_connected()
                async for raw in ws:
                    try:
                        msg = json.loads(raw)
                    except Exception:
                        continue
                    if msg.get("kind") == "invite_result":
                        self._on_invite_result(msg)
                    else:
                        self._on_sync_event(raw)
        except Exception:
            pass
        self.connected = False
