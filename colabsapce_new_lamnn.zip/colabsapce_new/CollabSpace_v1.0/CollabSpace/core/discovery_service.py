"""UDP LAN friend discovery with signed beacons."""
import json
import socket
import threading
import time
import uuid

from core.crypto_identity import IdentityManager


class DiscoveryService:
    def __init__(
        self,
        user_hash: str,
        display_name: str,
        version: str,
        device_name: str,
        identity: IdentityManager,
        friends_manager,
        on_friend_online,
        on_friend_offline,
        invite_port: int = 46874,
        beacon_port: int = 45891,
        interval_sec: int = 6,
        ttl_sec: int = 15,
    ):
        self.user_hash = user_hash
        self.display_name = display_name
        self.version = version
        self.device_name = device_name
        self.identity = identity
        self.friends = friends_manager
        self.on_friend_online = on_friend_online
        self.on_friend_offline = on_friend_offline
        self.beacon_port = beacon_port
        self.invite_port = invite_port
        self.interval_sec = interval_sec
        self.ttl_sec = ttl_sec
        self.running = False
        self._tx = None
        self._rx = None
        self._seen = {}
        self._nonce_seen = {}

    def start(self):
        if self.running:
            return
        self.running = True
        self._tx = threading.Thread(target=self._broadcast_loop, daemon=True)
        self._rx = threading.Thread(target=self._listen_loop, daemon=True)
        self._tx.start()
        self._rx.start()

    def stop(self):
        self.running = False

    def diagnostics_snapshot(self) -> dict:
        return {
            "running": bool(self.running),
            "beacon_port": int(self.beacon_port),
            "invite_port": int(self.invite_port),
            "nearby_count": len(self._seen),
            "nearby": list(self._seen.values()),
        }

    def _build_payload(self):
        return {
            "user_hash": self.user_hash,
            "display_name": self.display_name,
            "app_version": self.version,
            "device_name": self.device_name,
            "timestamp": int(time.time()),
            "nonce": str(uuid.uuid4()),
            "public_key": self.identity.public_key_b64(),
            "invite_port": self.invite_port,
        }

    def _broadcast_loop(self):
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        while self.running:
            if not self.friends.is_discovery_enabled():
                time.sleep(1.0)
                continue
            payload = self._build_payload()
            signed = {
                "payload": payload,
                "signature": self.identity.sign_payload(payload),
            }
            try:
                raw = json.dumps(signed).encode("utf-8")
                sock.sendto(raw, ("255.255.255.255", self.beacon_port))
            except OSError:
                pass
            self._purge_offline()
            time.sleep(self.interval_sec)

    def _listen_loop(self):
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(("", self.beacon_port))
        sock.settimeout(1.0)
        while self.running:
            try:
                msg, addr = sock.recvfrom(8192)
            except socket.timeout:
                self._purge_offline()
                continue
            except OSError:
                continue
            try:
                packet = json.loads(msg.decode("utf-8"))
                payload = packet.get("payload", {})
                signature = packet.get("signature", "")
            except Exception:
                continue

            remote_hash = payload.get("user_hash", "")
            if not remote_hash:
                continue
            # Allow discovery from another device even if same username/hash is used.
            if remote_hash == self.user_hash and payload.get("public_key", "") == self.identity.public_key_b64():
                continue
            if not self.friends.discovery_accepts(remote_hash):
                continue
            nonce = payload.get("nonce", "")
            if nonce in self._nonce_seen:
                continue
            self._nonce_seen[nonce] = time.time()
            if abs(int(time.time()) - int(payload.get("timestamp", 0))) > 30:
                continue
            if not self._verify(packet):
                continue
            just_seen = remote_hash not in self._seen
            self._seen[remote_hash] = {
                "last_seen": time.time(),
                "ip": addr[0],
                "port": payload.get("invite_port", 0),
                "display_name": payload.get("display_name", "Friend"),
                "device_name": payload.get("device_name", ""),
                "public_key": payload.get("public_key", ""),
            }
            self.friends.mark_reconnected(remote_hash)
            if just_seen and self.friends.should_surface_nearby(remote_hash):
                self.on_friend_online(remote_hash, self._seen[remote_hash])
            self._purge_nonce()

    def _verify(self, packet: dict) -> bool:
        payload = packet.get("payload", {})
        signature = packet.get("signature", "")
        pub = payload.get("public_key", "")
        if not pub:
            friend = self.friends.get_by_hash(payload.get("user_hash", ""))
            if friend:
                pub = friend.get("public_key", "")
        if not pub:
            return False
        return IdentityManager.verify_payload(payload, signature, pub)

    def _purge_nonce(self):
        now = time.time()
        stale = [k for k, t in self._nonce_seen.items() if now - t > 120]
        for k in stale:
            self._nonce_seen.pop(k, None)

    def _purge_offline(self):
        now = time.time()
        stale = [h for h, row in self._seen.items() if now - row.get("last_seen", 0) > self.ttl_sec]
        for h in stale:
            row = self._seen.pop(h, None)
            self.friends.mark_offline(h)
            if row:
                self.on_friend_offline(h, row)
