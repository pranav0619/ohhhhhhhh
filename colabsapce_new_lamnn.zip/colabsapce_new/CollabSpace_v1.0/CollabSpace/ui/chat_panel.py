"""Simple team chat panel for active collaboration session."""
import tkinter as tk
from datetime import datetime

from ui.theme import BG, PANEL, PANEL2, TEXT, DIM, ACCENT, btn


class ChatPanel(tk.Frame):
    def __init__(self, parent, get_current_user):
        super().__init__(parent, bg=BG)
        self._get_current_user = get_current_user
        self._send_cb = None
        self._status_var = tk.StringVar(value="Disconnected")
        self._build()

    def _build(self):
        header = tk.Frame(self, bg=PANEL, pady=10)
        header.pack(fill=tk.X)
        tk.Label(
            header,
            text="  Team Chat",
            bg=PANEL,
            fg=TEXT,
            font=("Segoe UI", 13, "bold"),
        ).pack(side=tk.LEFT)
        tk.Label(
            header,
            text="Use this after connecting with teammates",
            bg=PANEL,
            fg=DIM,
            font=("Segoe UI", 9),
        ).pack(side=tk.RIGHT, padx=10)
        tk.Label(
            header,
            textvariable=self._status_var,
            bg=PANEL,
            fg=DIM,
            font=("Segoe UI", 9, "bold"),
        ).pack(side=tk.RIGHT, padx=(0, 10))

        body = tk.Frame(self, bg=BG, padx=12, pady=12)
        body.pack(fill=tk.BOTH, expand=True)

        self._log = tk.Text(
            body,
            bg=PANEL2,
            fg=TEXT,
            insertbackground=TEXT,
            relief=tk.FLAT,
            bd=0,
            wrap=tk.WORD,
            state=tk.DISABLED,
            font=("Segoe UI", 10),
        )
        self._log.pack(fill=tk.BOTH, expand=True)

        composer = tk.Frame(body, bg=BG, pady=8)
        composer.pack(fill=tk.X)
        self._entry = tk.Entry(
            composer,
            bg=PANEL,
            fg=TEXT,
            insertbackground=TEXT,
            relief=tk.FLAT,
            bd=6,
            font=("Segoe UI", 10),
        )
        self._entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 8))
        self._entry.bind("<Return>", lambda _e: self.send_local_message())
        btn(composer, "Send", self.send_local_message, bg=ACCENT, fg="white").pack(side=tk.RIGHT)
        btn(composer, "Clear", self.clear_messages, bg=PANEL2, fg=TEXT).pack(side=tk.RIGHT, padx=(0, 8))

    def set_sender(self, send_cb):
        self._send_cb = send_cb

    def refresh(self):
        return

    def send_local_message(self):
        text = (self._entry.get() or "").strip()
        if not text:
            return
        current = self._get_current_user() or {}
        sender = current.get("username", "You")
        self.add_message(sender, text, incoming=False)
        self._entry.delete(0, tk.END)
        if self._send_cb:
            self._send_cb(text)

    def add_message(self, sender: str, text: str, incoming: bool = True):
        when = datetime.now().strftime("%H:%M")
        prefix = "Teammate" if incoming else "You"
        line = f"[{when}] {prefix} ({sender}): {text}\n"
        self._log.config(state=tk.NORMAL)
        self._log.insert(tk.END, line)
        self._log.see(tk.END)
        self._log.config(state=tk.DISABLED)

    def set_status(self, text: str):
        self._status_var.set((text or "").strip() or "Disconnected")

    def clear_messages(self):
        self._log.config(state=tk.NORMAL)
        self._log.delete("1.0", tk.END)
        self._log.config(state=tk.DISABLED)
