"""ui/settings_panel.py — user profile and app settings."""
import tkinter as tk
from tkinter import messagebox
from ui.theme import *
from core.members import get_members, member_by_id, update_member, add_member

class SettingsPanel(tk.Frame):
    def __init__(self, parent, on_update=None, on_share=None, friends_manager=None):
        super().__init__(parent, bg=BG)
        self._on_update = on_update
        self._on_share = on_share
        self._friends = friends_manager
        self._selected_member_id = None
        self._build()

    def _build(self):
        hdr = tk.Frame(self, bg=PANEL, pady=10)
        hdr.pack(fill=tk.X)
        tk.Label(hdr, text="  Settings", bg=PANEL, fg=TEXT,
                 font=("Segoe UI",13,"bold")).pack(side=tk.LEFT, padx=8)

        self._content = tk.Frame(self, bg=BG)
        self._content.pack(fill=tk.BOTH, expand=True, padx=16, pady=14)

        self._build_profile_form()
        self._build_add_member_form()
        self._build_discovery_form()

        separator(self)
        self._member_list = tk.Frame(self, bg=BG)
        self._member_list.pack(fill=tk.BOTH, expand=True, padx=16, pady=10)
        self.refresh()

    def _build_profile_form(self):
        frame = tk.Frame(self._content, bg=PANEL2, padx=12, pady=12)
        frame.pack(fill=tk.X, pady=(0,10))
        tk.Label(frame, text="My Profile", bg=PANEL2, fg=TEXT,
                 font=("Segoe UI",11,"bold")).pack(anchor=tk.W)

        self._profile_name = tk.Entry(frame, bg=PANEL, fg=TEXT)
        self._profile_name.pack(fill=tk.X, pady=4)
        self._profile_role = tk.Entry(frame, bg=PANEL, fg=TEXT)
        self._profile_role.pack(fill=tk.X, pady=4)
        self._profile_status = tk.Entry(frame, bg=PANEL, fg=TEXT)
        self._profile_status.pack(fill=tk.X, pady=4)
        self._profile_task = tk.Entry(frame, bg=PANEL, fg=TEXT)
        self._profile_task.pack(fill=tk.X, pady=4)

        tk.Button(frame, text="Update Profile", command=self._save_profile,
                  bg=ACCENT, fg="white", relief=tk.FLAT, bd=0).pack(pady=6)

    def _build_add_member_form(self):
        frame = tk.Frame(self._content, bg=PANEL2, padx=12, pady=12)
        frame.pack(fill=tk.X, pady=(0,10))
        tk.Label(frame, text="Add New Teammate", bg=PANEL2, fg=TEXT,
                 font=("Segoe UI",11,"bold")).pack(anchor=tk.W)

        self._new_name = tk.Entry(frame, bg=PANEL, fg=TEXT)
        self._new_name.insert(0, "Full name")
        self._new_name.bind("<FocusIn>", lambda _: self._new_name.delete(0,tk.END) if self._new_name.get()=="Full name" else None)
        self._new_name.pack(fill=tk.X, pady=4)

        self._new_role = tk.Entry(frame, bg=PANEL, fg=TEXT)
        self._new_role.insert(0, "Role")
        self._new_role.bind("<FocusIn>", lambda _: self._new_role.delete(0,tk.END) if self._new_role.get()=="Role" else None)
        self._new_role.pack(fill=tk.X, pady=4)

        tk.Button(frame, text="Add Teammate", command=self._add_member,
                  bg=SUCCESS, fg="white", relief=tk.FLAT, bd=0).pack(pady=6)

        # Share project permissions
        pr = tk.Frame(self._content, bg=PANEL2, padx=12, pady=12)
        pr.pack(fill=tk.X, pady=(0,10))
        tk.Label(pr, text="Project Sharing", bg=PANEL2, fg=TEXT,
                 font=("Segoe UI",11,"bold")).pack(anchor=tk.W)
        self._share_username = tk.Entry(pr, bg=PANEL, fg=TEXT)
        self._share_username.insert(0, "Username")
        self._share_username.bind("<FocusIn>", lambda _: self._share_username.delete(0,tk.END) if self._share_username.get()=="Username" else None)
        self._share_username.pack(fill=tk.X, pady=4)
        self._share_perm = tk.StringVar(value="read")
        tk.OptionMenu(pr, self._share_perm, "read", "write").pack(fill=tk.X)
        tk.Button(pr, text="Grant Access", command=self._grant_access,
                  bg=ACCENT, fg="white", relief=tk.FLAT, bd=0).pack(pady=6)

    def _build_discovery_form(self):
        frame = tk.Frame(self._content, bg=PANEL2, padx=12, pady=12)
        frame.pack(fill=tk.X, pady=(0, 10))
        tk.Label(frame, text="LAN Discovery", bg=PANEL2, fg=TEXT,
                 font=("Segoe UI",11,"bold")).pack(anchor=tk.W)
        enabled = True
        if self._friends:
            enabled = self._friends.is_discovery_enabled()
        self._discovery_enabled = tk.BooleanVar(value=enabled)
        tk.Checkbutton(
            frame,
            text="Enable nearby friend discovery",
            variable=self._discovery_enabled,
            bg=PANEL2,
            fg=TEXT,
            selectcolor=PANEL,
            activebackground=PANEL2,
            activeforeground=TEXT,
            command=self._toggle_discovery,
        ).pack(anchor=tk.W, pady=4)
        self._discovery_all = tk.BooleanVar(value=(self._friends.discovery_scope() == "all") if self._friends else False)
        tk.Checkbutton(
            frame,
            text="Show all app users on this WiFi (not only friend list)",
            variable=self._discovery_all,
            bg=PANEL2,
            fg=TEXT,
            selectcolor=PANEL,
            activebackground=PANEL2,
            activeforeground=TEXT,
            command=self._toggle_discovery_scope,
        ).pack(anchor=tk.W, pady=2)
        tk.Label(frame, text="Friends (mutual only)", bg=PANEL2, fg=DIM, font=FONT_SM).pack(anchor=tk.W, pady=(8, 4))
        ff = tk.Frame(frame, bg=PANEL2)
        ff.pack(fill=tk.X)
        self._friend_username = tk.Entry(ff, bg=PANEL, fg=TEXT)
        self._friend_username.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 6))
        self._friend_username.insert(0, "Friend username")
        self._friend_name = tk.Entry(ff, bg=PANEL, fg=TEXT, width=18)
        self._friend_name.pack(side=tk.LEFT, padx=(0, 6))
        self._friend_name.insert(0, "Display name")
        tk.Button(ff, text="Add", command=self._add_friend, bg=SUCCESS, fg="white", bd=0, relief=tk.FLAT).pack(side=tk.LEFT)
        self._friends_list = tk.Listbox(frame, bg=PANEL, fg=TEXT, height=4, bd=0, highlightthickness=0)
        self._friends_list.pack(fill=tk.X, pady=6)
        tk.Button(frame, text="Remove selected friend", command=self._remove_friend, bg=ERROR, fg="white", bd=0, relief=tk.FLAT).pack(anchor=tk.W)
        self._refresh_friends_list()

    def refresh(self):
        for w in self._member_list.winfo_children(): w.destroy()
        self._selected_member_id = None

        members = get_members()
        if not members:
            tk.Label(self._member_list, text="No team members yet.", bg=BG, fg=DIM).pack(anchor=tk.W)
            return

        for m in members:
            row = tk.Frame(self._member_list, bg=PANEL2, pady=4, padx=4)
            row.pack(fill=tk.X, pady=2)
            tk.Label(row, text=m["name"], bg=PANEL2, fg=TEXT).pack(side=tk.LEFT)
            tk.Label(row, text=m["role"], bg=PANEL2, fg=DIM).pack(side=tk.LEFT, padx=8)
            tk.Button(row, text="Edit", command=lambda uid=m["id"]: self._load_user(uid),
                      bg=ACCENT, fg="white", bd=0, relief=tk.FLAT).pack(side=tk.RIGHT, padx=2)
            tk.Button(row, text="Remove", command=lambda uid=m["id"]: self._remove_user(uid),
                      bg=ERROR, fg="white", bd=0, relief=tk.FLAT).pack(side=tk.RIGHT)

    def _load_user(self, uid):
        member = member_by_id(uid)
        if not member:
            messagebox.showerror("Error", "Member not found")
            return
        self._selected_member_id = uid
        self._profile_name.delete(0,tk.END); self._profile_name.insert(0, member["name"])
        self._profile_role.delete(0,tk.END); self._profile_role.insert(0, member["role"])
        self._profile_status.delete(0,tk.END); self._profile_status.insert(0, member["status"])
        self._profile_task.delete(0,tk.END); self._profile_task.insert(0, member["task"])

    def _save_profile(self):
        if not self._selected_member_id:
            messagebox.showinfo("Info", "Select a member from the list to edit first.")
            return
        try:
            update_member(self._selected_member_id,
                          name=self._profile_name.get(),
                          role=self._profile_role.get(),
                          status=self._profile_status.get(),
                          task=self._profile_task.get())
            if self._on_update: self._on_update()
            self.refresh()
            messagebox.showinfo("Saved", "Member updated")
        except ValueError as e:
            messagebox.showerror("Error", str(e))

    def _add_member(self):
        name = self._new_name.get().strip()
        if not name or name == "Full name":
            messagebox.showerror("Error", "Enter a valid name")
            return
        role = self._new_role.get().strip() or "Member"
        try:
            add_member(name=name, role=role)
            self._new_name.delete(0,tk.END)
            self._new_role.delete(0,tk.END)
            self.refresh()
            if self._on_update: self._on_update()
            messagebox.showinfo("Added", f"{name} was added to the team")
        except ValueError as e:
            messagebox.showerror("Error", str(e))

    def _remove_user(self, uid):
        from core.members import remove_member
        try:
            remove_member(uid)
            if self._on_update: self._on_update()
            self.refresh()
        except ValueError as e:
            messagebox.showerror("Error", str(e))

    def _grant_access(self):
        user = self._share_username.get().strip().lower()
        perm = self._share_perm.get().strip().lower()
        if not user or user == 'username':
            messagebox.showerror('Error', 'Enter a username')
            return
        if self._on_share:
            try:
                self._on_share(user, perm)
                messagebox.showinfo('Done', f'Granted {perm} access to {user}')
            except Exception as e:
                messagebox.showerror('Error', str(e))

    def _toggle_discovery(self):
        if self._friends:
            self._friends.set_discovery_enabled(self._discovery_enabled.get())

    def _toggle_discovery_scope(self):
        if self._friends:
            self._friends.set_discovery_scope("all" if self._discovery_all.get() else "friends")

    def _refresh_friends_list(self):
        if not hasattr(self, "_friends_list"):
            return
        self._friends_list.delete(0, tk.END)
        if not self._friends:
            return
        for f in self._friends.all_friends():
            self._friends_list.insert(tk.END, f"{f.get('username')} ({f.get('display_name')})")

    def _add_friend(self):
        if not self._friends:
            return
        u = self._friend_username.get().strip().lower()
        n = self._friend_name.get().strip()
        if not u or u == "friend username":
            messagebox.showerror("Error", "Enter friend username")
            return
        try:
            self._friends.add_friend(u, n or u)
            self._refresh_friends_list()
            messagebox.showinfo("Added", f"{u} added to friend list")
        except ValueError as e:
            messagebox.showerror("Error", str(e))

    def _remove_friend(self):
        if not self._friends:
            return
        sel = self._friends_list.curselection()
        if not sel:
            return
        text = self._friends_list.get(sel[0])
        username = text.split(" ", 1)[0]
        self._friends.remove_friend(username)
        self._refresh_friends_list()
